// دالة اختيارية: ترسل إشعارًا حقيقيًا للهواتف حتى والتطبيق مغلق.
// تحتاج خطة Blaze في Firebase ونشرها من الكمبيوتر: firebase deploy --only functions
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();

async function sendAll(title, body, link) {
  const snap = await admin.firestore().collection('khtokens').get();
  const tokens = snap.docs.map(d => d.id);
  for (let i = 0; i < tokens.length; i += 500) {
    const chunk = tokens.slice(i, i + 500);
    const res = await admin.messaging().sendEachForMulticast({
      tokens: chunk,
      notification: { title: title, body: body || '' },
      data: { link: link || '' },
      android: { priority: 'high', notification: { channelId: 'ka_main' } }
    });
    res.responses.forEach((r, k) => {
      const code = r.error && r.error.code || '';
      if (!r.success && /not-registered|invalid-registration|invalid-argument/.test(code)) {
        admin.firestore().collection('khtokens').doc(chunk[k]).delete();
      }
    });
  }
}

exports.onContent = onDocumentCreated('khcontent/{id}', (e) => {
  const d = e.data.data();
  if (d.draft) return null;
  return sendAll('جديد: ' + d.title, d.summary || '', '#/item/' + e.params.id);
});

exports.onNotify = onDocumentCreated('khnotify/{id}', (e) => {
  const d = e.data.data();
  return sendAll(d.title || '', d.body || '', d.link || '');
});
