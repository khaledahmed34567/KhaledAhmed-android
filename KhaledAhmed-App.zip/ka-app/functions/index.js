// دالة اختيارية: ترسل إشعارًا حقيقيًا للهواتف حتى والتطبيق مغلق.
// تحتاج خطة Blaze في Firebase ونشرها من الكمبيوتر: firebase deploy --only functions
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();

async function sendAll(title, body, link) {
  const snap = await admin.firestore().collection('khtokens').get();
  const tokens = snap.docs.map(d => d.id);
  for (let i = 0; i < tokens.length; i += 500) {
    const chunk = tokens.slice(i, i + 500);
    const res = await admin.messaging().sendEachForMulticast({
      tokens: chunk,
      notification: { title: title, body: body || '' },
      data: { link: link || '' },
      android: { priority: 'high', notification: { channelId: 'ka_main' } }
    });
    res.responses.forEach((r, k) => {
      const code = r.error && r.error.code || '';
      if (!r.success && /not-registered|invalid-registration|invalid-argument/.test(code)) {
        admin.firestore().collection('khtokens').doc(chunk[k]).delete();
      }
    });
  }
}

exports.onContent = onDocumentCreated('khcontent/{id}', (e) => {
  const d = e.data.data();
  if (d.draft) return null;
  return sendAll('جديد: ' + d.title, d.summary || '', '#/item/' + e.params.id);
});

exports.onNotify = onDocumentCreated('khnotify/{id}', (e) => {
  const d = e.data.data();
  return sendAll(d.title || '', d.body || '', d.link || '');
});

// وسيط آمن لـ IntelBase: يبقى المفتاح في Secret Manager ولا يصل إلى التطبيق.
// الإعداد: firebase functions:secrets:set IB_KEY ثم firebase deploy --only functions
const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const IB_KEY = defineSecret('IB_KEY');
exports.ibLookup = onRequest({ secrets: [IB_KEY], region: 'us-central1' }, async (req, res) => {
  try {
    if (req.method !== 'POST') { res.status(405).send(''); return; }
    const m = (req.get('Authorization') || '').match(/^Bearer (.+)$/);
    if (!m) { res.status(401).json({ error: 'auth' }); return; }
    const dec = await admin.auth().verifyIdToken(m[1]);
    if (!dec.email_verified) { res.status(403).json({ error: 'verify' }); return; }
    const day = new Date().toISOString().slice(0, 10);
    const ref = admin.firestore().collection('khrate').doc(dec.uid + '_' + day);
    const n = await admin.firestore().runTransaction(async (t) => {
      const s = await t.get(ref);
      const c = (s.exists ? s.data().n : 0) + 1;
      t.set(ref, { n: c, t: Date.now() });
      return c;
    });
    if (n > 20) { res.status(429).json({ error: 'limit' }); return; }
    const b = req.body || {};
    const path = String(b.path || '');
    if (!/^\/lookup\/(email|modules)$/.test(path)) { res.status(400).json({ error: 'path' }); return; }
    const get = b.method === 'GET';
    const r = await fetch('https://api.intelbase.is' + path, {
      method: get ? 'GET' : 'POST',
      headers: { 'x-api-key': IB_KEY.value(), 'Content-Type': 'application/json' },
      body: get ? undefined : JSON.stringify(b.body || {})
    });
    res.status(r.status).type('application/json').send(await r.text());
  } catch (e) {
    res.status(500).json({ error: 'server' });
  }
});
