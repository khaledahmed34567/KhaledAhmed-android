#!/bin/bash
set -e
mkdir -p www/fonts native/assets/fonts
dl(){ curl -fsSL --retry 3 --max-time 60 -o "$2" "$1" && [ -s "$2" ] || rm -f "$2"; }
dl https://files.catbox.moe/va4cz0.otf www/fonts/head400.otf
dl https://files.catbox.moe/sgpf34.otf www/fonts/head700.otf
dl https://files.catbox.moe/2k6107.otf www/fonts/text400.otf
dl https://files.catbox.moe/4rjalb.otf www/fonts/text700.otf
dl https://files.catbox.moe/mplj7v.otf www/fonts/time.otf
dl https://files.catbox.moe/uqr0yx.otf www/fonts/note.otf
dl https://files.catbox.moe/flmb6d.otf www/fonts/warn.otf
dl https://files.catbox.moe/1xmhcz.otf www/fonts/must.otf
[ -f www/fonts/head700.otf ] && cp www/fonts/head700.otf native/assets/fonts/head.otf || true
[ -f www/fonts/text400.otf ] && cp www/fonts/text400.otf native/assets/fonts/text.otf || true
[ -f www/fonts/time.otf ] && cp www/fonts/time.otf native/assets/fonts/time.otf || true
python3 - <<'PY'
import os
p='www/style.css'
s=open(p,encoding='utf-8').read()
m={'va4cz0':'head400','sgpf34':'head700','2k6107':'text400','4rjalb':'text700','mplj7v':'time','uqr0yx':'note','flmb6d':'warn','1xmhcz':'must'}
for k,v in m.items():
    if os.path.exists('www/fonts/%s.otf'%v):
        s=s.replace('https://files.catbox.moe/%s.otf'%k,'fonts/%s.otf'%v)
open(p,'w',encoding='utf-8').write(s)
print('fonts localized:',[v for v in m.values() if os.path.exists('www/fonts/%s.otf'%v)])
PY
