#!/bin/bash
set -e
mkdir -p www/fonts native/assets/fonts
dl(){ curl -fsSL --retry 3 --max-time 60 -o "$2" "$1" && [ -s "$2" ] || rm -f "$2"; }
dl https://files.catbox.moe/va4cz0.otf www/fonts/head400.otf
dl https://files.catbox.moe/sgpf34.otf www/fonts/head700.otf
dl https://files.catbox.moe/2k6107.otf www/fonts/text400.otf
dl https://files.catbox.moe/4rjalb.otf www/fonts/text700.otf
dl https://files.catbox.moe/mplj7v.otf www/fonts/time.otf
dl https://files.catbox.moe/uqr0yx.otf www/fonts/note.otf
dl https://files.catbox.moe/flmb6d.otf www/fonts/warn.otf
dl https://files.catbox.moe/1xmhcz.otf www/fonts/must.otf
[ -f www/fonts/head700.otf ] && cp www/fonts/head700.otf native/assets/fonts/head.otf || true
[ -f www/fonts/text400.otf ] && cp www/fonts/text400.otf native/assets/fonts/text.otf || true
[ -f www/fonts/time.otf ] && cp www/fonts/time.otf native/assets/fonts/time.otf || true
python3 - <<'PY'
import os
p='www/style.css'
s=open(p,encoding='utf-8').read()
m={'va4cz0':'head400','sgpf34':'head700','2k6107':'text400','4rjalb':'text700','mplj7v':'time','uqr0yx':'note','flmb6d':'warn','1xmhcz':'must'}
for k,v in m.items():
    if os.path.exists('www/fonts/%s.otf'%v):
        s=s.replace('https://files.catbox.moe/%s.otf'%k,'fonts/%s.otf'%v)
open(p,'w',encoding='utf-8').write(s)
print('fonts localized:',[v for v in m.values() if os.path.exists('www/fonts/%s.otf'%v)])
PY

mkdir -p www/lib/fb
dl https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js www/lib/pdf.min.js
dl https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js www/lib/pdf.worker.min.js
dl https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js www/lib/highlight.min.js
python3 - <<'PY'
import os,re,urllib.request
# 1) reader and code highlighting
p='www/app.js';s=open(p,encoding='utf-8').read()
if os.path.exists('www/lib/pdf.min.js') and os.path.exists('www/lib/pdf.worker.min.js'):
    s=s.replace('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js','lib/pdf.min.js').replace('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js','lib/pdf.worker.min.js')
    print('pdf.js localized')
h=open('www/index.html',encoding='utf-8').read()
if os.path.exists('www/lib/highlight.min.js'):
    h=h.replace('https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js','lib/highlight.min.js');open('www/index.html','w',encoding='utf-8').write(h);print('highlight.js localized')
# 2) Firebase SDK (ES modules) with all of its internal imports
base='https://www.gstatic.com/firebasejs/12.18.0/'
def fetch(u):
    return urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=60).read().decode('utf-8')
done={};queue=['firebase-app.js','firebase-auth.js','firebase-firestore.js'];ok=True
try:
    while queue:
        n=queue.pop()
        if n in done: continue
        src=fetch(base+n)
        for m in re.finditer(r'https://www\.gstatic\.com/firebasejs/12\.18\.0/([A-Za-z0-9_.\-]+\.js)',src):
            if m.group(1) not in done: queue.append(m.group(1))
        for m in re.finditer(r'(?:from|import)\s*\(?\s*["\']\./([A-Za-z0-9_.\-]+\.js)["\']',src):
            if m.group(1) not in done: queue.append(m.group(1))
        done[n]=src
    for n,src in done.items():
        src=re.sub(r'https://www\.gstatic\.com/firebasejs/12\.18\.0/([A-Za-z0-9_.\-]+\.js)',lambda m:'./'+m.group(1),src)
        open('www/lib/fb/'+n,'w',encoding='utf-8').write(src)
except Exception as e:
    ok=False;print('firebase localize failed:',e)
if ok and done:
    s=s.replace(base,'./lib/fb/');print('firebase localized:',sorted(done))
open(p,'w',encoding='utf-8').write(s)
PY
