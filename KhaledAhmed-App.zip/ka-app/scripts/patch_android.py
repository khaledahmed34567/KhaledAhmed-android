import os,re,shutil,glob
pkg='com.khaledahmed.app'
A='android/app/src/main'
pdir=A+'/java/'+pkg.replace('.','/')
os.makedirs(pdir,exist_ok=True)
for f in glob.glob('native/java/*.java'):
    shutil.copy(f,pdir)
shutil.copytree('native/res',A+'/res',dirs_exist_ok=True)
if os.path.isdir('native/assets'):
    shutil.copytree('native/assets',A+'/assets',dirs_exist_ok=True)
repo=os.environ.get('GH_REPO','').strip() or 'khaledahmed34567/KhaledAhmed-android'
import subprocess
sig=''
try:
    out=subprocess.run(['keytool','-list','-v','-keystore','keystore/debug.keystore','-storepass','android','-alias','androiddebugkey'],capture_output=True,text=True,timeout=60).stdout
    mm=re.search(r'SHA1:\s*([0-9A-Fa-f:]{59})',out)
    if mm: sig=mm.group(1).upper()
except Exception as ex:
    print('keytool failed',ex)
print('signature sha1:',sig or 'unknown (check disabled)')
open(A+'/res/values/ka_cfg.xml','w',encoding='utf-8').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="gh_repo" translatable="false">%s</string>\n    <string name="sig_sha1" translatable="false">%s</string>\n</resources>\n'%(repo,sig))
print('update repo:',repo)
for f in glob.glob(A+'/res/drawable*/splash.png'):
    shutil.copy('native/splash.png',f)

# manifest
p=A+'/AndroidManifest.xml'
m=open(p,encoding='utf-8').read()
extra="""
        <receiver android:name=".KaWidget" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/ka_widget_info" />
        </receiver>
        <meta-data android:name="com.google.firebase.messaging.default_notification_channel_id" android:value="ka_main" />
        <meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_stat_ka" />
        <meta-data android:name="com.google.firebase.messaging.default_notification_color" android:resource="@color/ka_purple" />
    """
if 'KaWidget' not in m:
    m=m.replace('</application>',extra+'</application>',1)
perms=''
for perm in ['android.permission.POST_NOTIFICATIONS','android.permission.USE_BIOMETRIC','android.permission.VIBRATE','android.permission.SET_WALLPAPER','android.permission.REQUEST_INSTALL_PACKAGES']:
    if perm not in m:
        perms+='    <uses-permission android:name="%s" />\n'%perm
if perms:
    m=m.replace('<application',perms+'    <application',1)
if 'KaCveWidget' not in m:
    cv="""
        <receiver android:name=".KaCveWidget" android:exported="true" android:label="@string/cve_label">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/ka_cve_info" />
        </receiver>
    """
    m=m.replace('</application>',cv+'</application>',1)
if 'KaInfoWidget' not in m:
    inf="""
        <receiver android:name=".KaInfoWidget" android:exported="true" android:label="@string/info_label">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/ka_info_info" />
        </receiver>
    """
    m=m.replace('</application>',inf+'</application>',1)
if 'KaQuickWidget' not in m:
    more="""
        <receiver android:name=".KaQuickWidget" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/ka_quick_info" />
        </receiver>
        <service android:name=".KaTile" android:exported="true" android:icon="@drawable/ic_stat_ka" android:label="@string/tile_label" android:permission="android.permission.BIND_QUICK_SETTINGS_TILE">
            <intent-filter>
                <action android:name="android.service.quicksettings.action.QS_TILE" />
            </intent-filter>
        </service>
    """
    m=m.replace('</application>',more+'</application>',1)
m=m.replace('android:allowBackup="true"','android:allowBackup="false"')
if 'usesCleartextTraffic' not in m:
    m=m.replace('<application','<application android:usesCleartextTraffic="false"',1)
if 'KaFileProvider' not in m:
    prov="""
        <provider android:name=".KaFileProvider" android:authorities="${applicationId}.updates" android:exported="false" android:grantUriPermissions="true">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/ka_paths" />
        </provider>
    """
    m=m.replace('</application>',prov+'</application>',1)
if 'khaledapp' not in m:
    act='''
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="khaledapp" />
            </intent-filter>
            <meta-data android:name="android.app.shortcuts" android:resource="@xml/shortcuts" />
        '''
    m=m.replace('</activity>',act+'</activity>',1)
open(p,'w',encoding='utf-8').write(m)

# gradle deps
g=open('android/app/build.gradle',encoding='utf-8').read()
extra_deps="\n    implementation 'androidx.biometric:biometric:1.1.0'\n    implementation 'com.google.android.gms:play-services-auth:21.2.0'\n    implementation 'androidx.work:work-runtime:2.9.1'"
if 'androidx.biometric' not in g:
    dep="implementation project(':capacitor-android')"
    if dep in g:
        g=g.replace(dep,dep+extra_deps,1)
    else:
        g,n=re.subn(r'dependencies\s*\{',lambda m:m.group(0)+extra_deps,g,count=1)
        assert n==1,'dependencies block not found in app/build.gradle'
    print('dependencies added')
open('android/app/build.gradle','w',encoding='utf-8').write(g)

# minSdk 29 (MediaStore downloads)
v=open('android/variables.gradle',encoding='utf-8').read()
v=re.sub(r'minSdkVersion\s*=\s*\d+','minSdkVersion = 29',v)
open('android/variables.gradle','w',encoding='utf-8').write(v)

# unique versionCode per build so the APK updates over the old one
bn=int(os.environ.get('BUILD_NO','0') or 0)
pk=open('VERSION').read().strip() if os.path.exists('VERSION') else '0'
code=max(2,bn+10)
g2=open('android/app/build.gradle',encoding='utf-8').read()
g2=re.sub(r'versionCode\s+\d+','versionCode %d'%code,g2,count=1)
g2=re.sub(r'versionName\s+"[^"]*"','versionName "1.%s.%d"'%(pk,bn),g2,count=1)
open('android/app/build.gradle','w',encoding='utf-8').write(g2)
print('versionCode',code,'versionName 1.%s.%d'%(pk,bn))

# explicit stable signing so every build updates over the previous one
shutil.copy('keystore/debug.keystore','android/app/debug.keystore')
g3=open('android/app/build.gradle',encoding='utf-8').read()
if 'signingConfigs' not in g3:
    g3,n3=re.subn(r'android\s*\{',"android {\n    signingConfigs {\n        debug {\n            storeFile file('debug.keystore')\n            storePassword 'android'\n            keyAlias 'androiddebugkey'\n            keyPassword 'android'\n        }\n    }",g3,count=1)
    assert n3==1,'android block not found'
    open('android/app/build.gradle','w',encoding='utf-8').write(g3)
    print('explicit debug signing added')

# splash background (Android 12+)
sp=A+'/res/values/styles.xml'
if os.path.exists(sp):
    s=open(sp,encoding='utf-8').read()
    if 'windowSplashScreenBackground' not in s:
        s=re.sub(r'(<style name="AppTheme.NoActionBarLaunch"[^>]*>)',r'\1\n        <item name="windowSplashScreenBackground">#000000</item>',s,count=1)
        open(sp,'w',encoding='utf-8').write(s)

# google-services
for src in ['android-config/google-services.json']:
    if os.path.exists(src):
        shutil.copy(src,'android/app/google-services.json')
        print('google-services.json installed')
print('patched')

g5=open('android/app/build.gradle',encoding='utf-8').read()
if 'debuggable' not in g5:
    g5,n5=re.subn(r'buildTypes\s*\{',"buildTypes {\n        debug {\n            debuggable false\n        }",g5,count=1)
    open('android/app/build.gradle','w',encoding='utf-8').write(g5)
    print('debuggable disabled' if n5 else 'buildTypes block not found')
