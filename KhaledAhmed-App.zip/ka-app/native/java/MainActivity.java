package com.khaledahmed.app;

import android.os.Bundle;
import android.view.WindowManager;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.getcapacitor.BridgeActivity;
import java.util.concurrent.TimeUnit;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    getSharedPreferences("ka", 0).edit().putString("crash", android.util.Log.getStackTraceString(e)).commit();
                } catch (Exception x) {
                }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
        registerPlugin(AppBridge.class);
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        try {
            Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(NotifyWorker.class, 15, TimeUnit.MINUTES).setConstraints(cons).build();
            WorkManager wm = WorkManager.getInstance(getApplicationContext());
            wm.enqueueUniquePeriodicWork("ka_notify", ExistingPeriodicWorkPolicy.KEEP, req);
            wm.enqueue(new OneTimeWorkRequest.Builder(NotifyWorker.class).setConstraints(cons).build());
        } catch (Exception e) {
        }
    }
}
