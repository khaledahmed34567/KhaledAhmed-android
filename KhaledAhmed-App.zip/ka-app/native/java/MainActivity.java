package com.khaledahmed.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    getSharedPreferences("ka", 0).edit().putString("crash", android.util.Log.getStackTraceString(e)).commit();
                } catch (Exception x) {
                }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
        registerPlugin(AppBridge.class);
        super.onCreate(savedInstanceState);
    }
}
