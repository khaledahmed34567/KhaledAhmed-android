package com.khaledahmed.app;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.getcapacitor.BridgeActivity;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

public class MainActivity extends BridgeActivity {
    private boolean sigOk() {
        try {
            String exp = getString(R.string.sig_sha1);
            if (exp == null || exp.trim().length() < 20) return true;
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            Signature[] ss = pi.signingInfo.getApkContentsSigners();
            byte[] d = MessageDigest.getInstance("SHA-1").digest(ss[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d.length; i++) {
                if (i > 0) sb.append(':');
                sb.append(String.format("%02X", d[i]));
            }
            return sb.toString().equalsIgnoreCase(exp.trim());
        } catch (Exception e) {
            return true;
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    getSharedPreferences("ka", 0).edit().putString("crash", android.util.Log.getStackTraceString(e)).commit();
                } catch (Exception x) {
                }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
        registerPlugin(AppBridge.class);
        super.onCreate(savedInstanceState);
        if (!sigOk() || android.os.Debug.isDebuggerConnected()) {
            Toast.makeText(this, "نسخة غير موثوقة. ثبّت التطبيق من المصدر الرسمي.", Toast.LENGTH_LONG).show();
            finishAffinity();
            return;
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        try {
            Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(NotifyWorker.class, 15, TimeUnit.MINUTES).setConstraints(cons).build();
            WorkManager wm = WorkManager.getInstance(getApplicationContext());
            wm.enqueueUniquePeriodicWork("ka_notify", ExistingPeriodicWorkPolicy.KEEP, req);
            wm.enqueue(new OneTimeWorkRequest.Builder(NotifyWorker.class).setConstraints(cons).build());
        } catch (Exception e) {
        }
    }
}
