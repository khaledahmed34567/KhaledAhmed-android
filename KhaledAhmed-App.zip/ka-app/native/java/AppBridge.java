package com.khaledahmed.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import com.google.android.gms.common.GoogleApiAvailability;
import java.security.MessageDigest;
import android.os.Build;
import android.view.WindowManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.Executor;

@CapacitorPlugin(name = "AppBridge")
public class AppBridge extends Plugin {

    private static final HashMap<String, OutputStream> OUT = new HashMap<String, OutputStream>();
    private static final HashMap<String, String> URIS = new HashMap<String, String>();

    private int authenticators() {
        if (Build.VERSION.SDK_INT >= 30) {
            return BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL;
        }
        return BiometricManager.Authenticators.BIOMETRIC_WEAK;
    }

    @PluginMethod
    public void canBiometric(PluginCall call) {
        int r = BiometricManager.from(getContext()).canAuthenticate(authenticators());
        JSObject o = new JSObject();
        o.put("available", r == BiometricManager.BIOMETRIC_SUCCESS);
        o.put("code", r);
        call.resolve(o);
    }

    @PluginMethod
    public void firebaseReady(PluginCall call) {
        JSObject o = new JSObject();
        Context c = getContext();
        o.put("ready", c.getResources().getIdentifier("google_app_id", "string", c.getPackageName()) != 0);
        call.resolve(o);
    }

    @PluginMethod
    public void lastCrash(PluginCall call) {
        JSObject o = new JSObject();
        try {
            android.content.SharedPreferences sp = getContext().getSharedPreferences("ka", 0);
            String t = sp.getString("crash", "");
            o.put("text", t);
            if (t != null && t.length() > 0) sp.edit().remove("crash").commit();
        } catch (Exception e) {
        }
        call.resolve(o);
    }

    @PluginMethod
    public void diagnostics(PluginCall call) {
        JSObject o = new JSObject();
        try {
            Context c = getContext();
            o.put("pkg", c.getPackageName());
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            Signature[] sigs = pi.signingInfo.getApkContentsSigners();
            byte[] d = MessageDigest.getInstance("SHA-1").digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d.length; i++) {
                if (i > 0) sb.append(':');
                sb.append(String.format("%02X", d[i]));
            }
            o.put("sha1", sb.toString());
            int rid = c.getResources().getIdentifier("default_web_client_id", "string", c.getPackageName());
            o.put("webClientId", rid != 0);
            o.put("playServices", GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(c));
            o.put("biometric", BiometricManager.from(c).canAuthenticate(authenticators()));
        } catch (Exception e) {
            o.put("error", String.valueOf(e.getMessage()));
        }
        call.resolve(o);
    }

    @PluginMethod
    public void setSecure(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        final Activity act = getActivity();
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (on) {
                    act.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
                } else {
                    act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
                }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(getContext());
            if (m.isRequestPinAppWidgetSupported()) {
                String type = call.getString("type", "news");
                Class<?> cls = "quick".equals(type) ? KaQuickWidget.class : KaWidget.class;
                m.requestPinAppWidget(new ComponentName(getContext(), cls), null, null);
                call.resolve();
            } else {
                call.reject("not_supported");
            }
        } catch (Exception e) {
            call.reject("pin_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void biometricAuth(final PluginCall call) {
        final Activity act = getActivity();
        final String title = call.getString("title", "تأكيد الهوية");
        final String subtitle = call.getString("subtitle", "");
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Executor ex = ContextCompat.getMainExecutor(act);
                    BiometricPrompt bp = new BiometricPrompt((FragmentActivity) act, ex, new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            JSObject o = new JSObject();
                            o.put("ok", true);
                            call.resolve(o);
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            call.reject(String.valueOf(msg), String.valueOf(code));
                        }
                    });
                    BiometricPrompt.PromptInfo.Builder pb = new BiometricPrompt.PromptInfo.Builder()
                        .setTitle(title)
                        .setSubtitle(subtitle)
                        .setAllowedAuthenticators(authenticators());
                    if (Build.VERSION.SDK_INT < 30) {
                        pb.setNegativeButtonText("إلغاء");
                    }
                    bp.authenticate(pb.build());
                } catch (Exception e) {
                    call.reject("biometric_failed: " + e.getMessage());
                }
            }
        });
    }

    @PluginMethod
    public void googleSignIn(final PluginCall call) {
        String clientId = call.getString("clientId", "");
        if (clientId == null || clientId.isEmpty()) {
            int rid = getContext().getResources().getIdentifier("default_web_client_id", "string", getContext().getPackageName());
            if (rid != 0) clientId = getContext().getString(rid);
        }
        if (clientId == null || clientId.isEmpty()) {
            call.reject("no_client_id");
            return;
        }
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(clientId)
            .requestEmail()
            .build();
        final GoogleSignInClient client = GoogleSignIn.getClient(getActivity(), gso);
        client.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(Task<Void> task) {
                startActivityForResult(call, client.getSignInIntent(), "googleResult");
            }
        });
    }

    @ActivityCallback
    private void googleResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            Task<GoogleSignInAccount> t = GoogleSignIn.getSignedInAccountFromIntent(result.getData());
            GoogleSignInAccount a = t.getResult(ApiException.class);
            JSObject o = new JSObject();
            o.put("idToken", a.getIdToken());
            o.put("email", a.getEmail());
            call.resolve(o);
        } catch (ApiException e) {
            call.reject("google_failed", String.valueOf(e.getStatusCode()));
        }
    }

    @PluginMethod
    public void saveBegin(PluginCall call) {
        try {
            String name = call.getString("name", "file");
            String mime = call.getString("mime", "application/octet-stream");
            ContentResolver r = getContext().getContentResolver();
            boolean img = mime.startsWith("image/");
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, img ? Environment.DIRECTORY_PICTURES + "/KhaledAhmed" : Environment.DIRECTORY_DOWNLOADS);
            Uri base = img ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri u = r.insert(base, v);
            if (u == null) {
                call.reject("insert_failed");
                return;
            }
            OutputStream os = r.openOutputStream(u);
            String id = UUID.randomUUID().toString();
            OUT.put(id, os);
            URIS.put(id, u.toString());
            JSObject o = new JSObject();
            o.put("id", id);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("save_begin_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void saveChunk(PluginCall call) {
        OutputStream os = OUT.get(call.getString("id", ""));
        if (os == null) {
            call.reject("no_stream");
            return;
        }
        try {
            os.write(Base64.decode(call.getString("data", ""), Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("save_chunk_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void saveEnd(PluginCall call) {
        String id = call.getString("id", "");
        OutputStream os = OUT.remove(id);
        String u = URIS.remove(id);
        try {
            if (os != null) {
                os.flush();
                os.close();
            }
            JSObject o = new JSObject();
            o.put("uri", u);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("save_end_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setWallpaper(PluginCall call) {
        try {
            String uri = call.getString("uri", "");
            InputStream is = getContext().getContentResolver().openInputStream(Uri.parse(uri));
            WallpaperManager.getInstance(getContext()).setStream(is);
            is.close();
            call.resolve();
        } catch (Exception e) {
            call.reject("wallpaper_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void openFile(PluginCall call) {
        try {
            Uri u = Uri.parse(call.getString("uri", ""));
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, call.getString("mime", "*/*"));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent c = Intent.createChooser(i, "فتح بواسطة");
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(c);
            call.resolve();
        } catch (Exception e) {
            call.reject("open_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
            Intent c = Intent.createChooser(i, "مشاركة");
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(c);
            call.resolve();
        } catch (Exception e) {
            call.reject("share_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void updateWidget(PluginCall call) {
        try {
            KaWidget.updateAll(getContext());
        } catch (Exception e) {
        }
        call.resolve();
    }
}
