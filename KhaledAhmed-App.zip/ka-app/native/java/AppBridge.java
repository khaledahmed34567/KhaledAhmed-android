package com.khaledahmed.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.net.Uri;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;
import com.google.android.gms.common.GoogleApiAvailability;
import java.security.MessageDigest;
import android.os.Build;
import android.view.WindowManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.Executor;

@CapacitorPlugin(name = "AppBridge")
public class AppBridge extends Plugin {

    private TextToSpeech tts;
    private boolean ttsOk = false;
    private static final HashMap<String, OutputStream> OUT = new HashMap<String, OutputStream>();
    private static final HashMap<String, String> URIS = new HashMap<String, String>();

    private int authenticators() {
        if (Build.VERSION.SDK_INT >= 30) {
            return BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL;
        }
        return BiometricManager.Authenticators.BIOMETRIC_WEAK;
    }

    @PluginMethod
    public void canBiometric(PluginCall call) {
        int r = BiometricManager.from(getContext()).canAuthenticate(authenticators());
        JSObject o = new JSObject();
        o.put("available", r == BiometricManager.BIOMETRIC_SUCCESS);
        o.put("code", r);
        call.resolve(o);
    }

    @PluginMethod
    public void firebaseReady(PluginCall call) {
        JSObject o = new JSObject();
        Context c = getContext();
        o.put("ready", c.getResources().getIdentifier("google_app_id", "string", c.getPackageName()) != 0);
        call.resolve(o);
    }

    @PluginMethod
    public void lastCrash(PluginCall call) {
        JSObject o = new JSObject();
        try {
            android.content.SharedPreferences sp = getContext().getSharedPreferences("ka", 0);
            String t = sp.getString("crash", "");
            o.put("text", t);
            if (t != null && t.length() > 0) sp.edit().remove("crash").commit();
        } catch (Exception e) {
        }
        call.resolve(o);
    }

    @PluginMethod
    public void diagnostics(PluginCall call) {
        JSObject o = new JSObject();
        try {
            Context c = getContext();
            o.put("pkg", c.getPackageName());
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            Signature[] sigs = pi.signingInfo.getApkContentsSigners();
            byte[] d = MessageDigest.getInstance("SHA-1").digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d.length; i++) {
                if (i > 0) sb.append(':');
                sb.append(String.format("%02X", d[i]));
            }
            o.put("sha1", sb.toString());
            int rid = c.getResources().getIdentifier("default_web_client_id", "string", c.getPackageName());
            o.put("webClientId", rid != 0);
            o.put("playServices", GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(c));
            o.put("biometric", BiometricManager.from(c).canAuthenticate(authenticators()));
        } catch (Exception e) {
            o.put("error", String.valueOf(e.getMessage()));
        }
        call.resolve(o);
    }

    @PluginMethod
    public void setSecure(final PluginCall call) {
        final Activity act = getActivity();
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void markSeen(PluginCall call) {
        android.content.SharedPreferences.Editor e = getContext().getSharedPreferences("ka", 0).edit();
        if (call.hasOption("n")) {
            Double n = call.getDouble("n");
            if (n != null) e.putLong("seen_n", n.longValue());
        }
        if (call.hasOption("c")) e.putString("seen_c", call.getString("c", ""));
        e.apply();
        call.resolve();
    }

    @PluginMethod
    public void speak(final PluginCall call) {
        final String text = call.getString("text", "");
        final String lang = call.getString("lang", "ar");
        if (tts == null) {
            tts = new TextToSpeech(getContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int st) {
                    ttsOk = (st == TextToSpeech.SUCCESS);
                    if (ttsOk) {
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override
                            public void onStart(String id) {
                            }

                            @Override
                            public void onError(String id) {
                                notifyListeners("ttsDone", new JSObject());
                            }

                            @Override
                            public void onDone(String id) {
                                if ("ka_last".equals(id)) notifyListeners("ttsDone", new JSObject());
                            }
                        });
                    }
                    doSpeak(call, text, lang);
                }
            });
        } else {
            doSpeak(call, text, lang);
        }
    }

    private void doSpeak(PluginCall call, String text, String lang) {
        if (!ttsOk) {
            call.reject("tts_unavailable");
            return;
        }
        int r = tts.setLanguage(new Locale(lang));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            call.reject("no_voice");
            return;
        }
        int max = Math.min(TextToSpeech.getMaxSpeechInputLength(), 3500);
        tts.stop();
        int i = 0;
        int n = 0;
        while (i < text.length()) {
            int e = Math.min(text.length(), i + max);
            if (e < text.length()) {
                int sp = text.lastIndexOf(' ', e);
                if (sp > i + 200) e = sp;
            }
            boolean last = e >= text.length();
            tts.speak(text.substring(i, e), n == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, last ? "ka_last" : "ka_" + n);
            i = e;
            n++;
        }
        call.resolve();
    }

    @PluginMethod
    public void stopSpeak(PluginCall call) {
        if (tts != null) tts.stop();
        call.resolve();
    }

    @PluginMethod
    public void appInfo(PluginCall call) {
        JSObject o = new JSObject();
        try {
            Context c = getContext();
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            o.put("versionCode", pi.getLongVersionCode());
            o.put("versionName", pi.versionName);
        } catch (Exception e) {
            o.put("error", String.valueOf(e.getMessage()));
        }
        call.resolve(o);
    }

    @PluginMethod
    public void setAutoUpdate(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("on", true));
        getContext().getSharedPreferences("ka", 0).edit().putBoolean("auto_upd", on).apply();
        call.resolve();
    }

    @PluginMethod
    public void canInstall(PluginCall call) {
        JSObject o = new JSObject();
        o.put("ok", getContext().getPackageManager().canRequestPackageInstalls());
        call.resolve(o);
    }

    @PluginMethod
    public void openInstallSettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("settings_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void downloadUpdate(final PluginCall call) {
        final String u = call.getString("url", "");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File dir = new File(getContext().getCacheDir(), "updates");
                    dir.mkdirs();
                    File f = new File(dir, "KhaledAhmed.apk");
                    if (f.exists()) f.delete();
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setInstanceFollowRedirects(true);
                    int code = c.getResponseCode();
                    if (code >= 400) {
                        call.reject("http_" + code);
                        return;
                    }
                    long total = c.getContentLengthLong();
                    java.io.InputStream in = c.getInputStream();
                    FileOutputStream out = new FileOutputStream(f);
                    byte[] buf = new byte[65536];
                    long done = 0;
                    long last = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        done += n;
                        long now = System.currentTimeMillis();
                        if (now - last > 250) {
                            last = now;
                            JSObject o = new JSObject();
                            o.put("done", done);
                            o.put("total", total);
                            notifyListeners("updProgress", o);
                        }
                    }
                    out.close();
                    in.close();
                    JSObject r = new JSObject();
                    r.put("size", done);
                    call.resolve(r);
                } catch (Exception e) {
                    call.reject("download_failed: " + e.getMessage());
                }
            }
        }).start();
    }

    @PluginMethod
    public void installUpdate(PluginCall call) {
        try {
            File f = new File(new File(getContext().getCacheDir(), "updates"), "KhaledAhmed.apk");
            if (!f.exists()) {
                call.reject("no_file");
                return;
            }
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".updates", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("install_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void httpFetch(final PluginCall call) {
        final String u = call.getString("url", "");
        String host = "";
        try {
            host = new URL(u).getHost();
        } catch (Exception ex) {
        }
        if (!u.startsWith("https://") || !(host.equals("api.intelbase.is") || host.equals("api.xposedornot.com") || host.equals("cavalier.hudsonrock.com") || host.equals("api.pwnedpasswords.com") || host.equals("us-central1-cyberintel-d0d4f.cloudfunctions.net"))) {
            call.reject("host_not_allowed");
            return;
        }
        final String method = call.getString("method", "GET");
        final String body = call.getString("body", null);
        final JSObject hdrs = call.getObject("headers");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(120000);
                    c.setRequestMethod(method);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
                    c.setRequestProperty("Accept", "application/json");
                    if (hdrs != null) {
                        java.util.Iterator<String> it = hdrs.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            c.setRequestProperty(k, hdrs.getString(k));
                        }
                    }
                    if (body != null) {
                        c.setDoOutput(true);
                        OutputStream os = c.getOutputStream();
                        os.write(body.getBytes("UTF-8"));
                        os.close();
                    }
                    int code = c.getResponseCode();
                    java.io.InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    StringBuilder sb = new StringBuilder();
                    if (is != null) {
                        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(is, "UTF-8"));
                        String l;
                        while ((l = r.readLine()) != null) sb.append(l).append('\n');
                        r.close();
                    }
                    JSObject o = new JSObject();
                    o.put("status", code);
                    o.put("body", sb.toString());
                    call.resolve(o);
                } catch (Exception e) {
                    call.reject("http_failed: " + e.getMessage());
                }
            }
        }).start();
    }

    @PluginMethod
    public void voiceInput(PluginCall call) {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, call.getString("lang", "ar-EG"));
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث الآن");
            startActivityForResult(call, i, "voiceResult");
        } catch (Exception e) {
            call.reject("no_voice_input");
        }
    }

    @ActivityCallback
    private void voiceResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            ArrayList<String> a = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            JSObject o = new JSObject();
            o.put("text", (a != null && a.size() > 0) ? a.get(0) : "");
            call.resolve(o);
        } else {
            call.reject("cancelled");
        }
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(getContext());
            if (m.isRequestPinAppWidgetSupported()) {
                String type = call.getString("type", "news");
                Class<?> cls = "quick".equals(type) ? KaQuickWidget.class : KaWidget.class;
                m.requestPinAppWidget(new ComponentName(getContext(), cls), null, null);
                call.resolve();
            } else {
                call.reject("not_supported");
            }
        } catch (Exception e) {
            call.reject("pin_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void biometricAuth(final PluginCall call) {
        final Activity act = getActivity();
        final String title = call.getString("title", "تأكيد الهوية");
        final String subtitle = call.getString("subtitle", "");
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Executor ex = ContextCompat.getMainExecutor(act);
                    BiometricPrompt bp = new BiometricPrompt((FragmentActivity) act, ex, new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            JSObject o = new JSObject();
                            o.put("ok", true);
                            call.resolve(o);
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            call.reject(String.valueOf(msg), String.valueOf(code));
                        }
                    });
                    BiometricPrompt.PromptInfo.Builder pb = new BiometricPrompt.PromptInfo.Builder()
                        .setTitle(title)
                        .setSubtitle(subtitle)
                        .setAllowedAuthenticators(authenticators());
                    if (Build.VERSION.SDK_INT < 30) {
                        pb.setNegativeButtonText("إلغاء");
                    }
                    bp.authenticate(pb.build());
                } catch (Exception e) {
                    call.reject("biometric_failed: " + e.getMessage());
                }
            }
        });
    }

    @PluginMethod
    public void googleSignIn(final PluginCall call) {
        String clientId = call.getString("clientId", "");
        if (clientId == null || clientId.isEmpty()) {
            int rid = getContext().getResources().getIdentifier("default_web_client_id", "string", getContext().getPackageName());
            if (rid != 0) clientId = getContext().getString(rid);
        }
        if (clientId == null || clientId.isEmpty()) {
            call.reject("no_client_id");
            return;
        }
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(clientId)
            .requestEmail()
            .build();
        final GoogleSignInClient client = GoogleSignIn.getClient(getActivity(), gso);
        client.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(Task<Void> task) {
                startActivityForResult(call, client.getSignInIntent(), "googleResult");
            }
        });
    }

    @ActivityCallback
    private void googleResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            Task<GoogleSignInAccount> t = GoogleSignIn.getSignedInAccountFromIntent(result.getData());
            GoogleSignInAccount a = t.getResult(ApiException.class);
            JSObject o = new JSObject();
            o.put("idToken", a.getIdToken());
            o.put("email", a.getEmail());
            call.resolve(o);
        } catch (ApiException e) {
            call.reject("google_failed", String.valueOf(e.getStatusCode()));
        }
    }

    @PluginMethod
    public void saveBegin(PluginCall call) {
        try {
            String name = call.getString("name", "file");
            String mime = call.getString("mime", "application/octet-stream");
            ContentResolver r = getContext().getContentResolver();
            boolean img = mime.startsWith("image/");
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, img ? Environment.DIRECTORY_PICTURES + "/KhaledAhmed" : Environment.DIRECTORY_DOWNLOADS);
            Uri base = img ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri u = r.insert(base, v);
            if (u == null) {
                call.reject("insert_failed");
                return;
            }
            OutputStream os = r.openOutputStream(u);
            String id = UUID.randomUUID().toString();
            OUT.put(id, os);
            URIS.put(id, u.toString());
            JSObject o = new JSObject();
            o.put("id", id);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("save_begin_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void saveChunk(PluginCall call) {
        OutputStream os = OUT.get(call.getString("id", ""));
        if (os == null) {
            call.reject("no_stream");
            return;
        }
        try {
            os.write(Base64.decode(call.getString("data", ""), Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("save_chunk_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void saveEnd(PluginCall call) {
        String id = call.getString("id", "");
        OutputStream os = OUT.remove(id);
        String u = URIS.remove(id);
        try {
            if (os != null) {
                os.flush();
                os.close();
            }
            JSObject o = new JSObject();
            o.put("uri", u);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("save_end_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setWallpaper(PluginCall call) {
        try {
            String uri = call.getString("uri", "");
            InputStream is = getContext().getContentResolver().openInputStream(Uri.parse(uri));
            WallpaperManager.getInstance(getContext()).setStream(is);
            is.close();
            call.resolve();
        } catch (Exception e) {
            call.reject("wallpaper_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void openFile(PluginCall call) {
        try {
            Uri u = Uri.parse(call.getString("uri", ""));
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, call.getString("mime", "*/*"));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent c = Intent.createChooser(i, "فتح بواسطة");
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(c);
            call.resolve();
        } catch (Exception e) {
            call.reject("open_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
            Intent c = Intent.createChooser(i, "مشاركة");
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(c);
            call.resolve();
        } catch (Exception e) {
            call.reject("share_failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void updateWidget(PluginCall call) {
        try {
            KaWidget.updateAll(getContext());
        } catch (Exception e) {
        }
        call.resolve();
    }
}
