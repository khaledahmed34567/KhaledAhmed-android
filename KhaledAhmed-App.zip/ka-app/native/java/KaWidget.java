package com.khaledahmed.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.NumberFormat;
import java.util.Locale;

public class KaWidget extends AppWidgetProvider {
    static final String BASE = "https://firestore.googleapis.com/v1/projects/cyberintel-d0d4f/databases/(default)/documents";
    static final String KEY = "AIzaSyCTGnFOK7m_xNod8mwBPB5HTgTP2BrNm6o";
    static Data last = null;

    static class Data {
        String[] titles = new String[3];
        long visitors = -1;
    }

    @Override
    public void onUpdate(final Context c, final AppWidgetManager m, final int[] ids) {
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    refresh(c, m, ids);
                } catch (Exception e) {
                } finally {
                    pr.finish();
                }
            }
        }).start();
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        try {
            draw(c, m, id, last != null ? last : new Data());
        } catch (Exception e) {
        }
    }

    static void updateAll(final Context c) {
        final AppWidgetManager m = AppWidgetManager.getInstance(c);
        final int[] ids = m.getAppWidgetIds(new ComponentName(c, KaWidget.class));
        if (ids == null || ids.length == 0) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    refresh(c, m, ids);
                } catch (Exception e) {
                }
            }
        }).start();
    }

    static void refresh(Context c, AppWidgetManager m, int[] ids) {
        Data d = fetch();
        last = d;
        for (int id : ids) draw(c, m, id, d);
    }

    static String http(String u, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        if (body != null) {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            OutputStream o = c.getOutputStream();
            o.write(body.getBytes("UTF-8"));
            o.close();
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder s = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) s.append(l);
        r.close();
        return s.toString();
    }

    static Data fetch() {
        Data d = new Data();
        try {
            String q = "{\"structuredQuery\":{\"from\":[{\"collectionId\":\"khcontent\"}],\"orderBy\":[{\"field\":{\"fieldPath\":\"createdAt\"},\"direction\":\"DESCENDING\"}],\"limit\":12}}";
            JSONArray a = new JSONArray(http(BASE + ":runQuery?key=" + KEY, q));
            int n = 0;
            for (int i = 0; i < a.length() && n < 3; i++) {
                JSONObject o = a.getJSONObject(i);
                if (!o.has("document")) continue;
                JSONObject f = o.getJSONObject("document").getJSONObject("fields");
                if (f.has("draft") && f.getJSONObject("draft").optBoolean("booleanValue", false)) continue;
                if (!f.has("title")) continue;
                d.titles[n++] = f.getJSONObject("title").optString("stringValue", "");
            }
        } catch (Exception e) {
        }
        return d;
    }

    static Typeface tf(Context c, String f) {
        try {
            return Typeface.createFromAsset(c.getAssets(), "fonts/" + f);
        } catch (Exception e) {
            return Typeface.DEFAULT;
        }
    }

    static StaticLayout layout(String t, TextPaint p, int w, int maxLines, Layout.Alignment a) {
        return StaticLayout.Builder.obtain(t, 0, t.length(), p, Math.max(w, 10))
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setAlignment(a)
            .setTextDirection(TextDirectionHeuristics.ANYRTL_LTR)
            .build();
    }

    static void draw(Context c, AppWidgetManager m, int id, Data d) {
        Bundle o = m.getAppWidgetOptions(id);
        float dens = c.getResources().getDisplayMetrics().density;
        int wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110);
        if (wdp < 60) wdp = 250;
        if (hdp < 40) hdp = 110;
        int w = Math.min((int) (wdp * dens), 1100);
        int h = Math.min((int) (hdp * dens), 700);
        float s = (float) w / wdp;
        Bitmap b = render(c, d, w, h, s);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_ka);
        rv.setImageViewBitmap(R.id.wimg, b);
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li != null) {
            PendingIntent pi = PendingIntent.getActivity(c, 0, li, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.wroot, pi);
        }
        m.updateAppWidget(id, rv);
    }

    static Bitmap render(Context c, Data d, int w, int h, float s) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = 22 * s;
        RectF r = new RectF(0, 0, w, h);
        p.setColor(0xFF0A0A0A);
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(new RadialGradient(w * 0.5f, 0, w * 0.75f, AccentUtil.alpha(AccentUtil.c1(c), 0x55), AccentUtil.alpha(AccentUtil.c1(c), 0x00), Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * s);
        p.setColor(0x33FFFFFF);
        cv.drawRoundRect(new RectF(s, s, w - s, h - s), rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        float pad = 14 * s;
        Typeface head = tf(c, "head.otf");
        Typeface text = tf(c, "text.otf");
        Typeface time = tf(c, "time.otf");

        Bitmap lg = BitmapFactory.decodeResource(c.getResources(), R.drawable.ka_logo);
        float lh = Math.min(h * 0.30f, 34 * s);
        float lw = lg != null ? lh * lg.getWidth() / lg.getHeight() : 0;
        if (lg != null) {
            p.setFilterBitmap(true);
            cv.drawBitmap(lg, null, new RectF(w - pad - lw, pad, w - pad, pad + lh), p);
        }

        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(head);
        tp.setColor(AccentUtil.c2(c));
        tp.setTextSize(12 * s);
        StaticLayout hl = layout("آخر المستجدات", tp, (int) (w * 0.4f), 1, Layout.Alignment.ALIGN_OPPOSITE);
        cv.save();
        cv.translate(pad, pad + (lh - hl.getHeight()) / 2f);
        hl.draw(cv);
        cv.restore();

        float y = pad + lh + 10 * s;
        float bw = 6 * s;
        int lineW = (int) (w - 2 * pad - bw - 8 * s);
        tp.setTypeface(text);
        tp.setColor(0xFFF4F4F4);
        tp.setTextSize(13.5f * s);
        int shown = 0;
        for (int i = 0; i < 3; i++) {
            String t = d.titles[i];
            if (t == null || t.length() == 0) continue;
            StaticLayout l = layout(t, tp, lineW, 1, Layout.Alignment.ALIGN_NORMAL);
            if (y + l.getHeight() > h - pad - 18 * s) break;
            p.setColor(AccentUtil.c1(c));
            cv.drawCircle(w - pad - bw / 2f, y + l.getHeight() / 2f, bw / 2f, p);
            cv.save();
            cv.translate(pad, y);
            l.draw(cv);
            cv.restore();
            y += l.getHeight() + 7 * s;
            shown++;
        }
        if (shown == 0) {
            tp.setColor(0xFF888888);
            StaticLayout l = layout("افتح التطبيق لعرض آخر المستجدات", tp, lineW, 2, Layout.Alignment.ALIGN_NORMAL);
            cv.save();
            cv.translate(pad, y);
            l.draw(cv);
            cv.restore();
        }
        {
            String v = "آخر تحديث  " + new java.text.SimpleDateFormat("HH:mm", new Locale("ar", "EG")).format(new java.util.Date());
            tp.setTypeface(time);
            tp.setColor(0xFF42BE65);
            tp.setTextSize(11.5f * s);
            StaticLayout vl = layout(v, tp, (int) (w - 2 * pad), 1, Layout.Alignment.ALIGN_NORMAL);
            cv.save();
            cv.translate(pad, h - pad - vl.getHeight());
            vl.draw(cv);
            cv.restore();
        }
        return b;
    }
}
