package com.khaledahmed.app;

public class KaFileProvider extends androidx.core.content.FileProvider {
}
