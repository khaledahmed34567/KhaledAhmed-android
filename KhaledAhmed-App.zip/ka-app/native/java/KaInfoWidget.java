package com.khaledahmed.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;

public class KaInfoWidget extends AppWidgetProvider {
    static final String[] DQ = {
        "التصميم الجيد هو الذي لا تلاحظه، لأنه يعمل ببساطة.",
        "ابدأ بالمشكلة لا بالشكل، فالشكل يأتي بعد أن تفهم من تخدم.",
        "البساطة ليست غياب التفاصيل، بل اختيار التفاصيل التي تهم.",
        "المساحة الفارغة جزء من التصميم وليست فراغًا يجب ملؤه.",
        "اجعل الأمر الصحيح هو الأسهل على المستخدم.",
        "الخط الواضح أصدق من زخرفة تُتعب العين.",
        "لا تصمم لنفسك فقط، جرّب تصميمك على شخص لا يعرفه.",
        "الاتساق يبني الثقة: نفس الشيء يبدو ويعمل دائمًا بنفس الطريقة.",
        "اللون يوجّه الانتباه، فاستخدمه لما يستحق الانتباه فقط.",
        "التصميم قرار تتخذه مئة مرة، والتفاصيل الصغيرة تصنع الفرق.",
        "الأمان جزء من التجربة، والتصميم الذي يحمي المستخدم يحترمه.",
        "كل عنصر زائد يستهلك انتباه المستخدم، فاحذف ما لا يخدمه."
    };

    @Override
    public void onUpdate(final Context c, final AppWidgetManager m, final int[] ids) {
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    render(c, m, ids, true);
                } catch (Exception e) {
                } finally {
                    pr.finish();
                }
            }
        }).start();
    }

    @Override
    public void onAppWidgetOptionsChanged(final Context c, final AppWidgetManager m, final int id, Bundle o) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    render(c, m, new int[]{id}, false);
                } catch (Exception e) {
                }
            }
        }).start();
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, KaInfoWidget.class));
        if (ids.length > 0) {
            Intent i = new Intent(c, KaInfoWidget.class);
            i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            c.sendBroadcast(i);
        }
    }

    static String http(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/json");
        if (c.getResponseCode() != 200) throw new Exception("http " + c.getResponseCode());
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder s = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) s.append(l);
        r.close();
        return s.toString();
    }

    static String clean(String h) {
        String t = h.replaceAll("<[^>]+>", "")
            .replace("&#8217;", "'").replace("&#8216;", "'").replace("&#8220;", "\"").replace("&#8221;", "\"")
            .replace("&#8211;", "-").replace("&#8212;", "-").replace("&hellip;", "...").replace("&amp;", "&")
            .replaceAll("&[a-zA-Z#0-9]+;", " ");
        return t.trim();
    }

    static JSONObject load(Context c, boolean fetch) {
        SharedPreferences sp = c.getSharedPreferences("ka", 0);
        JSONObject d = new JSONObject();
        try {
            String cached = sp.getString("info_json", "");
            if (!cached.isEmpty()) d = new JSONObject(cached);
        } catch (Exception e) {
        }
        if (!fetch) return d;
        long now = System.currentTimeMillis();
        String city = sp.getString("city", "Cairo");
        try {
            if (now - sp.getLong("info_wt", 0) > 25 * 60 * 1000L || !city.equals(d.optString("cityKey", ""))) {
                String lat = sp.getString("lat", "");
                String lon = sp.getString("lon", "");
                String name = sp.getString("cname", city);
                if (lat.isEmpty() || lon.isEmpty()) {
                    JSONObject g = new JSONObject(http("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(city, "UTF-8") + "&count=1&language=ar&format=json"));
                    JSONArray rs = g.optJSONArray("results");
                    if (rs != null && rs.length() > 0) {
                        JSONObject p = rs.getJSONObject(0);
                        lat = String.valueOf(p.getDouble("latitude"));
                        lon = String.valueOf(p.getDouble("longitude"));
                        name = p.optString("name", city);
                        sp.edit().putString("lat", lat).putString("lon", lon).putString("cname", name).apply();
                    }
                }
                if (!lat.isEmpty()) {
                    JSONObject w = new JSONObject(http("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"));
                    JSONObject cu = w.getJSONObject("current");
                    JSONObject dl = w.getJSONObject("daily");
                    d.put("cityKey", city);
                    d.put("city", name);
                    d.put("temp", Math.round(cu.getDouble("temperature_2m")));
                    d.put("code", cu.getInt("weather_code"));
                    d.put("hum", Math.round(cu.optDouble("relative_humidity_2m", 0)));
                    d.put("wind", Math.round(cu.optDouble("wind_speed_10m", 0)));
                    d.put("max", Math.round(dl.getJSONArray("temperature_2m_max").getDouble(0)));
                    d.put("min", Math.round(dl.getJSONArray("temperature_2m_min").getDouble(0)));
                    sp.edit().putLong("info_wt", now).apply();
                }
            }
        } catch (Exception e) {
        }
        try {
            if (now - sp.getLong("info_qt", 0) > 6 * 3600 * 1000L || d.optString("qtext", "").isEmpty()) {
                try {
                    JSONArray a = new JSONArray(http("https://quotesondesign.com/wp-json/wp/v2/posts/?orderby=rand&per_page=1"));
                    JSONObject q = a.getJSONObject(0);
                    String tx = clean(q.getJSONObject("content").getString("rendered"));
                    String by = clean(q.getJSONObject("title").getString("rendered"));
                    if (tx.isEmpty() || tx.length() > 240) throw new Exception("bad quote");
                    d.put("qtext", tx);
                    d.put("qby", by);
                } catch (Exception e) {
                    int day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
                    d.put("qtext", DQ[day % DQ.length]);
                    d.put("qby", "");
                }
                sp.edit().putLong("info_qt", now).apply();
            }
        } catch (Exception e) {
        }
        sp.edit().putString("info_json", d.toString()).apply();
        return d;
    }

    static void render(Context c, AppWidgetManager m, int[] ids, boolean fetch) {
        JSONObject d = load(c, fetch);
        float dens = c.getResources().getDisplayMetrics().density;
        for (int id : ids) {
            Bundle o = m.getAppWidgetOptions(id);
            int wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
            int hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120);
            if (wdp < 100) wdp = 250;
            if (hdp < 70) hdp = 120;
            int w = Math.min((int) (wdp * dens), 1100);
            int h = Math.min((int) (hdp * dens), 700);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_info);
            rv.setImageViewBitmap(R.id.info_img, draw(c, d, w, h, dens));
            Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("khaledapp://go?h=" + Uri.encode("#/")));
            in.setPackage(c.getPackageName());
            rv.setOnClickPendingIntent(R.id.info_img, PendingIntent.getActivity(c, 300, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            m.updateAppWidget(id, rv);
        }
    }

    static String wxName(int code) {
        if (code == 0) return "صافٍ";
        if (code == 1) return "غالبًا صافٍ";
        if (code == 2) return "غائم جزئيًا";
        if (code == 3) return "غائم";
        if (code == 45 || code == 48) return "ضباب";
        if (code >= 51 && code <= 57) return "رذاذ";
        if (code >= 61 && code <= 67) return "مطر";
        if (code >= 71 && code <= 77) return "ثلج";
        if (code >= 80 && code <= 82) return "زخات مطر";
        if (code == 85 || code == 86) return "زخات ثلج";
        if (code >= 95) return "عاصفة رعدية";
        return "";
    }

    static Bitmap draw(Context c, JSONObject d, int w, int h, float s) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = 22 * s;
        RectF r = new RectF(2 * s, 2 * s, w - 2 * s, h - 2 * s);
        p.setColor(0xFF0E0E10);
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(new RadialGradient(w * 0.85f, 0, w * 0.8f, 0x4D7C5CFF, 0x007C5CFF, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s);
        p.setColor(0x33FFFFFF);
        cv.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        Typeface head = KaWidget.tf(c, "head.otf");
        Typeface text = KaWidget.tf(c, "text.otf");
        Typeface time = KaWidget.tf(c, "time.otf");
        float pad = 14 * s;
        boolean has = d.has("temp");
        float ir = Math.min(h * 0.17f, 26 * s);
        if (has) {
            wx(cv, d.optInt("code", 0), w - pad - ir, pad + ir + 4 * s, ir);
        }
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextAlign(Paint.Align.RIGHT);
        float rx = w - pad - ir * 2 - 14 * s;
        if (has) {
            tp.setTypeface(time);
            tp.setColor(0xFFFFFFFF);
            tp.setTextSize(Math.min(40 * s, h * 0.26f));
            float ty = pad + Math.min(40 * s, h * 0.26f) * 0.85f;
            cv.drawText(d.optInt("temp") + "°", rx, ty, tp);
            tp.setTypeface(head);
            tp.setTextSize(13 * s);
            tp.setColor(0xFFE8E8E8);
            cv.drawText(d.optString("city", "") + " - " + wxName(d.optInt("code", 0)), w - pad, ty + 20 * s, tp);
            tp.setTypeface(text);
            tp.setTextSize(11 * s);
            tp.setColor(0xFFA8A8A8);
            cv.drawText("العظمى " + d.optInt("max") + "°  الصغرى " + d.optInt("min") + "°  رطوبة " + d.optInt("hum") + "%  رياح " + d.optInt("wind"), w - pad, ty + 38 * s, tp);
        } else {
            tp.setTypeface(head);
            tp.setTextSize(14 * s);
            tp.setColor(0xFFA8A8A8);
            cv.drawText("جارِ تحميل الطقس...", w - pad, pad + 24 * s, tp);
        }
        float ly = h * 0.56f;
        p.setColor(0x26FFFFFF);
        cv.drawRect(pad, ly, w - pad, ly + s, p);

        String q = d.optString("qtext", "");
        if (q.isEmpty()) q = DQ[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % DQ.length];
        String by = d.optString("qby", "");
        TextPaint qp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        qp.setTypeface(text);
        qp.setColor(0xFFF2F2F2);
        int lw = (int) (w - 2 * pad);
        float size = 13 * s;
        StaticLayout sl = null;
        float avail = h - ly - 12 * s - (by.isEmpty() ? 0 : 16 * s);
        for (int i = 0; i < 4; i++) {
            qp.setTextSize(size);
            sl = StaticLayout.Builder.obtain(q, 0, q.length(), qp, lw).setAlignment(Layout.Alignment.ALIGN_NORMAL).setMaxLines(4).setEllipsize(TextUtils.TruncateAt.END).build();
            if (sl.getHeight() <= avail) break;
            size -= 1.2f * s;
        }
        cv.save();
        cv.translate(pad, ly + 8 * s);
        if (sl != null) sl.draw(cv);
        cv.restore();
        if (!by.isEmpty() && sl != null) {
            tp.setTypeface(head);
            tp.setTextSize(10.5f * s);
            tp.setColor(0xFFA99BFF);
            tp.setTextAlign(Paint.Align.RIGHT);
            cv.drawText("- " + by, w - pad, Math.min(h - 8 * s, ly + 8 * s + sl.getHeight() + 14 * s), tp);
        }
        return b;
    }

    static void wx(Canvas cv, int code, float cx, float cy, float r) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean sun = code <= 1;
        boolean part = code == 2;
        if (sun || part) {
            float sx = part ? cx - r * 0.35f : cx;
            float sy = part ? cy - r * 0.3f : cy;
            float sr = part ? r * 0.5f : r * 0.6f;
            p.setColor(0xFFFFC83D);
            cv.drawCircle(sx, sy, sr, p);
            p.setStrokeWidth(r * 0.1f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                cv.drawLine((float) (sx + Math.cos(a) * sr * 1.25), (float) (sy + Math.sin(a) * sr * 1.25), (float) (sx + Math.cos(a) * sr * 1.55), (float) (sy + Math.sin(a) * sr * 1.55), p);
            }
            if (sun) return;
        }
        p.setColor(code >= 95 ? 0xFF8E8E99 : 0xFFD9DCE3);
        float cy2 = part ? cy + r * 0.25f : cy - r * 0.1f;
        cv.drawCircle(cx - r * 0.35f, cy2 + r * 0.1f, r * 0.42f, p);
        cv.drawCircle(cx + r * 0.1f, cy2 - r * 0.15f, r * 0.55f, p);
        cv.drawCircle(cx + r * 0.5f, cy2 + r * 0.12f, r * 0.38f, p);
        cv.drawRect(cx - r * 0.4f, cy2 + r * 0.1f, cx + r * 0.5f, cy2 + r * 0.5f, p);
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        if (rain) {
            p.setColor(0xFF4FA3FF);
            p.setStrokeWidth(r * 0.12f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 3; i++) {
                float x = cx - r * 0.4f + i * r * 0.4f;
                cv.drawLine(x, cy2 + r * 0.65f, x - r * 0.12f, cy2 + r * 0.95f, p);
            }
        }
        if (snow) {
            p.setColor(0xFFFFFFFF);
            for (int i = 0; i < 3; i++) cv.drawCircle(cx - r * 0.4f + i * r * 0.4f, cy2 + r * 0.8f, r * 0.08f, p);
        }
        if (code >= 95) {
            Path b = new Path();
            b.moveTo(cx + r * 0.05f, cy2 + r * 0.5f);
            b.lineTo(cx - r * 0.15f, cy2 + r * 0.85f);
            b.lineTo(cx + r * 0.02f, cy2 + r * 0.85f);
            b.lineTo(cx - r * 0.1f, cy2 + r * 1.2f);
            b.lineTo(cx + r * 0.25f, cy2 + r * 0.75f);
            b.lineTo(cx + r * 0.08f, cy2 + r * 0.75f);
            b.close();
            p.setColor(0xFFFFC83D);
            cv.drawPath(b, p);
        }
        if (code == 45 || code == 48) {
            p.setColor(0xFFB0B4BD);
            p.setStrokeWidth(r * 0.1f);
            for (int i = 0; i < 3; i++) cv.drawLine(cx - r * 0.7f, cy2 + r * 0.7f + i * r * 0.2f, cx + r * 0.7f, cy2 + r * 0.7f + i * r * 0.2f, p);
        }
    }
}
