package com.khaledahmed.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class KaInfoWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(final Context c, final AppWidgetManager m, final int[] ids) {
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    render(c, m, ids, true);
                } catch (Exception e) {
                } finally {
                    pr.finish();
                }
            }
        }).start();
    }

    @Override
    public void onAppWidgetOptionsChanged(final Context c, final AppWidgetManager m, final int id, Bundle o) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    render(c, m, new int[]{id}, false);
                } catch (Exception e) {
                }
            }
        }).start();
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, KaInfoWidget.class));
        if (ids.length > 0) {
            Intent i = new Intent(c, KaInfoWidget.class);
            i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            c.sendBroadcast(i);
        }
    }

    static String http(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/json");
        if (c.getResponseCode() != 200) throw new Exception("http " + c.getResponseCode());
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder s = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) s.append(l);
        r.close();
        return s.toString();
    }

    static int method(String cc) {
        switch (cc) {
            case "EG": return 5;
            case "SA": return 4;
            case "AE": return 16;
            case "KW": return 9;
            case "QA": return 10;
            case "TR": return 13;
            case "MA": return 21;
            case "DZ": return 19;
            case "TN": return 18;
            case "JO": return 23;
            default: return 3;
        }
    }

    static JSONObject load(Context c, boolean fetch) {
        SharedPreferences sp = c.getSharedPreferences("ka", 0);
        JSONObject d = new JSONObject();
        try {
            String cached = sp.getString("info_json", "");
            if (!cached.isEmpty()) d = new JSONObject(cached);
        } catch (Exception e) {
        }
        if (!fetch) return d;
        long now = System.currentTimeMillis();
        String city = sp.getString("city", "Cairo");
        String today = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
        boolean needW = now - sp.getLong("info_wt", 0) > 25 * 60 * 1000L || !city.equals(d.optString("cityKey", ""));
        boolean needP = !today.equals(sp.getString("pt_date", "")) || !city.equals(sp.getString("pt_city", ""));
        try {
            String lat = sp.getString("lat", "");
            String lon = sp.getString("lon", "");
            String name = sp.getString("cname", city);
            String cc = sp.getString("cc", "");
            if ((needW || needP) && (lat.isEmpty() || lon.isEmpty())) {
                JSONObject g = new JSONObject(http("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(city, "UTF-8") + "&count=1&language=ar&format=json"));
                JSONArray rs = g.optJSONArray("results");
                if (rs != null && rs.length() > 0) {
                    JSONObject p = rs.getJSONObject(0);
                    lat = String.valueOf(p.getDouble("latitude"));
                    lon = String.valueOf(p.getDouble("longitude"));
                    name = p.optString("name", city);
                    cc = p.optString("country_code", "");
                    sp.edit().putString("lat", lat).putString("lon", lon).putString("cname", name).putString("cc", cc).apply();
                }
            }
            if (!lat.isEmpty() && needW) {
                try {
                    JSONObject w = new JSONObject(http("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"));
                    JSONObject cu = w.getJSONObject("current");
                    JSONObject dl = w.getJSONObject("daily");
                    d.put("cityKey", city);
                    d.put("city", name);
                    d.put("temp", Math.round(cu.getDouble("temperature_2m")));
                    d.put("code", cu.getInt("weather_code"));
                    d.put("hum", Math.round(cu.optDouble("relative_humidity_2m", 0)));
                    d.put("wind", Math.round(cu.optDouble("wind_speed_10m", 0)));
                    d.put("max", Math.round(dl.getJSONArray("temperature_2m_max").getDouble(0)));
                    d.put("min", Math.round(dl.getJSONArray("temperature_2m_min").getDouble(0)));
                    sp.edit().putLong("info_wt", now).apply();
                } catch (Exception e) {
                }
            }
            if (!lat.isEmpty() && needP) {
                try {
                    JSONObject a = new JSONObject(http("https://api.aladhan.com/v1/timings/" + today + "?latitude=" + lat + "&longitude=" + lon + "&method=" + method(cc)));
                    JSONObject t = a.getJSONObject("data").getJSONObject("timings");
                    JSONObject pt = new JSONObject();
                    String[] ks = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
                    for (int i = 0; i < ks.length; i++) {
                        String v = t.optString(ks[i], "");
                        pt.put(ks[i], v.length() >= 5 ? v.substring(0, 5) : v);
                    }
                    d.put("pt", pt);
                    sp.edit().putString("pt_date", today).putString("pt_city", city).apply();
                } catch (Exception e) {
                }
            }
        } catch (Exception e) {
        }
        sp.edit().putString("info_json", d.toString()).apply();
        return d;
    }

    static void render(Context c, AppWidgetManager m, int[] ids, boolean fetch) {
        JSONObject d = load(c, fetch);
        float dens = c.getResources().getDisplayMetrics().density;
        for (int id : ids) {
            Bundle o = m.getAppWidgetOptions(id);
            int wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
            int hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120);
            if (wdp < 100) wdp = 250;
            if (hdp < 70) hdp = 120;
            int w = Math.min((int) (wdp * dens), 1100);
            int h = Math.min((int) (hdp * dens), 700);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_info);
            rv.setImageViewBitmap(R.id.info_img, draw(c, d, w, h, dens));
            Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("khaledapp://go?h=" + Uri.encode("#/today")));
            in.setPackage(c.getPackageName());
            rv.setOnClickPendingIntent(R.id.info_img, PendingIntent.getActivity(c, 300, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            m.updateAppWidget(id, rv);
        }
    }

    static String wxName(int code) {
        if (code == 0) return "صافٍ";
        if (code == 1) return "غالبًا صافٍ";
        if (code == 2) return "غائم جزئيًا";
        if (code == 3) return "غائم";
        if (code == 45 || code == 48) return "ضباب";
        if (code >= 51 && code <= 57) return "رذاذ";
        if (code >= 61 && code <= 67) return "مطر";
        if (code >= 71 && code <= 77) return "ثلج";
        if (code >= 80 && code <= 82) return "زخات مطر";
        if (code == 85 || code == 86) return "زخات ثلج";
        if (code >= 95) return "عاصفة رعدية";
        return "";
    }

    static int glow(Context c, int code) {
        int hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        boolean night = hr < 6 || hr >= 19;
        if (code >= 95) return 0x669A6BFF;
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return 0x664FA3FF;
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return 0x55CFE8FF;
        if (code == 45 || code == 48) return 0x449AA0AA;
        if (code == 3) return 0x554F6D9B;
        return night ? AccentUtil.alpha(AccentUtil.c1(c), 0x66) : 0x66FFB020;
    }

    static String rem(int mins) {
        int h = mins / 60;
        int mm = mins % 60;
        return "بعد " + (h > 0 ? h + "س " : "") + mm + "د";
    }

    static String[] nextPrayer(JSONObject pt) {
        try {
            if (pt == null) return null;
            String[] ks = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
            String[] ar = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
            Calendar n = Calendar.getInstance();
            int cur = n.get(Calendar.HOUR_OF_DAY) * 60 + n.get(Calendar.MINUTE);
            for (int i = 0; i < 5; i++) {
                String t = pt.optString(ks[i], "");
                if (t.length() < 4) continue;
                String[] p = t.split(":");
                int mn = Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
                if (mn > cur) return new String[]{ar[i], t, rem(mn - cur)};
            }
            String t = pt.optString("Fajr", "");
            String[] p = t.split(":");
            int mn = Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
            return new String[]{ar[0] + " غدًا", t, rem(mn + 1440 - cur)};
        } catch (Exception e) {
            return null;
        }
    }

    static Bitmap draw(Context c, JSONObject d, int w, int h, float s) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = 24 * s;
        RectF r = new RectF(2 * s, 2 * s, w - 2 * s, h - 2 * s);
        p.setColor(0xFF0B0B0D);
        cv.drawRoundRect(r, rad, rad, p);
        int gl = glow(c, d.optInt("code", 0));
        p.setShader(new RadialGradient(w * 0.82f, h * 0.1f, w * 0.8f, gl, gl & 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s);
        p.setColor(0x33FFFFFF);
        cv.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        Typeface head = KaWidget.tf(c, "head.otf");
        Typeface text = KaWidget.tf(c, "text.otf");
        Typeface time = KaWidget.tf(c, "time.otf");
        float pad = 14 * s;
        TextPaint0 tp = new TextPaint0();

        // ---- prayer card (left) ----
        float x0 = pad, x1 = w * 0.40f, y0 = pad, y1 = h - pad, ch = y1 - y0;
        RectF pc = new RectF(x0, y0, x1, y1);
        p.setColor(0x16FFFFFF);
        cv.drawRoundRect(pc, 18 * s, 18 * s, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s);
        p.setColor(0x2AFFFFFF);
        cv.drawRoundRect(pc, 18 * s, 18 * s, p);
        p.setStyle(Paint.Style.FILL);
        float cx = (x0 + x1) / 2f;
        String[] np = nextPrayer(d.optJSONObject("pt"));
        tp.center();
        if (np != null) {
            tp.draw(cv, "الصلاة القادمة", cx, y0 + ch * 0.17f, text, Math.min(10 * s, ch * 0.12f), 0xFFA8A8A8);
            tp.draw(cv, np[0], cx, y0 + ch * 0.41f, head, Math.min(18 * s, ch * 0.22f), 0xFFFFFFFF);
            tp.draw(cv, np[1], cx, y0 + ch * 0.71f, time, Math.min(28 * s, ch * 0.32f), AccentUtil.c2(c));
            tp.draw(cv, np[2], cx, y0 + ch * 0.9f, text, Math.min(10.5f * s, ch * 0.12f), 0xFF42BE65);
        } else {
            tp.draw(cv, "الصلاة القادمة", cx, y0 + ch * 0.4f, head, Math.min(14 * s, ch * 0.18f), 0xFFE8E8E8);
            tp.draw(cv, "جارِ التحميل...", cx, y0 + ch * 0.65f, text, Math.min(11 * s, ch * 0.14f), 0xFFA8A8A8);
        }

        // ---- weather (right) ----
        boolean has = d.has("temp");
        float ir = Math.min(h * 0.16f, 22 * s);
        float rx = w - pad;
        if (has) {
            wx(cv, d.optInt("code", 0), rx - ir, pad + ir + 2 * s, ir);
            float ts = Math.min(36 * s, h * 0.24f);
            tp.right();
            tp.draw(cv, d.optInt("temp") + "°", rx - 2 * ir - 10 * s, pad + ts * 0.85f, time, ts, 0xFFFFFFFF);
            float y2 = pad + 2 * ir + 16 * s;
            tp.draw(cv, d.optString("city", "") + " - " + wxName(d.optInt("code", 0)), rx, y2, head, 12.5f * s, 0xFFE8E8E8);
            float ph = 24 * s;
            RectF pill = new RectF(x1 + 10 * s, h - pad - ph, rx, h - pad);
            p.setColor(0x16FFFFFF);
            cv.drawRoundRect(pill, ph / 2, ph / 2, p);
            tp.center();
            tp.draw(cv, d.optInt("max") + "° / " + d.optInt("min") + "°   رطوبة " + d.optInt("hum") + "%   رياح " + d.optInt("wind"), (pill.left + pill.right) / 2f, pill.centerY() + 4 * s, text, 10.5f * s, 0xFFD6D6D6);
        } else {
            tp.right();
            tp.draw(cv, "جارِ تحميل الطقس...", rx, pad + 24 * s, head, 14 * s, 0xFFA8A8A8);
        }
        return b;
    }

    static class TextPaint0 {
        Paint.Align al = Paint.Align.CENTER;

        void center() {
            al = Paint.Align.CENTER;
        }

        void right() {
            al = Paint.Align.RIGHT;
        }

        void draw(Canvas cv, String t, float x, float y, Typeface tf, float size, int color) {
            Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
            q.setTypeface(tf);
            q.setTextSize(size);
            q.setColor(color);
            q.setTextAlign(al);
            cv.drawText(t, x, y, q);
        }
    }

    static void wx(Canvas cv, int code, float cx, float cy, float r) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean sun = code <= 1;
        boolean part = code == 2;
        if (sun || part) {
            float sx = part ? cx - r * 0.35f : cx;
            float sy = part ? cy - r * 0.3f : cy;
            float sr = part ? r * 0.5f : r * 0.6f;
            p.setColor(0xFFFFC83D);
            cv.drawCircle(sx, sy, sr, p);
            p.setStrokeWidth(r * 0.1f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                cv.drawLine((float) (sx + Math.cos(a) * sr * 1.25), (float) (sy + Math.sin(a) * sr * 1.25), (float) (sx + Math.cos(a) * sr * 1.55), (float) (sy + Math.sin(a) * sr * 1.55), p);
            }
            if (sun) return;
        }
        p.setColor(code >= 95 ? 0xFF8E8E99 : 0xFFD9DCE3);
        float cy2 = part ? cy + r * 0.25f : cy - r * 0.1f;
        cv.drawCircle(cx - r * 0.35f, cy2 + r * 0.1f, r * 0.42f, p);
        cv.drawCircle(cx + r * 0.1f, cy2 - r * 0.15f, r * 0.55f, p);
        cv.drawCircle(cx + r * 0.5f, cy2 + r * 0.12f, r * 0.38f, p);
        cv.drawRect(cx - r * 0.4f, cy2 + r * 0.1f, cx + r * 0.5f, cy2 + r * 0.5f, p);
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        if (rain) {
            p.setColor(0xFF4FA3FF);
            p.setStrokeWidth(r * 0.12f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 3; i++) {
                float x = cx - r * 0.4f + i * r * 0.4f;
                cv.drawLine(x, cy2 + r * 0.65f, x - r * 0.12f, cy2 + r * 0.95f, p);
            }
        }
        if (snow) {
            p.setColor(0xFFFFFFFF);
            for (int i = 0; i < 3; i++) cv.drawCircle(cx - r * 0.4f + i * r * 0.4f, cy2 + r * 0.8f, r * 0.08f, p);
        }
        if (code >= 95) {
            Path b = new Path();
            b.moveTo(cx + r * 0.05f, cy2 + r * 0.5f);
            b.lineTo(cx - r * 0.15f, cy2 + r * 0.85f);
            b.lineTo(cx + r * 0.02f, cy2 + r * 0.85f);
            b.lineTo(cx - r * 0.1f, cy2 + r * 1.2f);
            b.lineTo(cx + r * 0.25f, cy2 + r * 0.75f);
            b.lineTo(cx + r * 0.08f, cy2 + r * 0.75f);
            b.close();
            p.setColor(0xFFFFC83D);
            cv.drawPath(b, p);
        }
        if (code == 45 || code == 48) {
            p.setColor(0xFFB0B4BD);
            p.setStrokeWidth(r * 0.1f);
            for (int i = 0; i < 3; i++) cv.drawLine(cx - r * 0.7f, cy2 + r * 0.7f + i * r * 0.2f, cx + r * 0.7f, cy2 + r * 0.7f + i * r * 0.2f, p);
        }
    }
}
