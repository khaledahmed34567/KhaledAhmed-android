package com.khaledahmed.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;

public class NotifyWorker extends Worker {
    static final String CH = "ka_main";
    static final String BASE = "https://firestore.googleapis.com/v1/projects/cyberintel-d0d4f/databases/(default)/documents";
    static final String KEY = "AIzaSyCTGnFOK7m_xNod8mwBPB5HTgTP2BrNm6o";

    public NotifyWorker(@NonNull Context c, @NonNull WorkerParameters p) {
        super(c, p);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            Context c = getApplicationContext();
            SharedPreferences sp = c.getSharedPreferences("ka", 0);
            ensureChannel(c);

            JSONObject n = latest("khnotify", "t");
            if (n != null) {
                JSONObject f = n.getJSONObject("fields");
                long t = num(f, "t");
                long last = sp.getLong("seen_n", -1);
                if (last < 0) {
                    sp.edit().putLong("seen_n", t).apply();
                } else if (t > last) {
                    show(c, 1002, str(f, "title"), str(f, "body"), str(f, "link"), str(f, "img"), str(f, "btn"), str(f, "btnUrl"));
                    sp.edit().putLong("seen_n", t).apply();
                }
            }

            JSONObject ct = latest("khcontent", "createdAt");
            if (ct != null) {
                JSONObject f = ct.getJSONObject("fields");
                String at = str(f, "createdAt");
                String last = sp.getString("seen_c", "");
                boolean draft = f.has("draft") && f.getJSONObject("draft").optBoolean("booleanValue", false);
                String name = ct.optString("name", "");
                String id = name.substring(name.lastIndexOf('/') + 1);
                if (last.isEmpty()) {
                    sp.edit().putString("seen_c", at).apply();
                } else if (at.compareTo(last) > 0) {
                    if (!draft) show(c, 1003, "جديد: " + str(f, "title"), str(f, "summary"), "#/item/" + id, "", "", "");
                    sp.edit().putString("seen_c", at).apply();
                }
            }
            checkUpdate(c, sp);
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    static boolean quiet(Context c) {
        SharedPreferences sp = c.getSharedPreferences("ka", 0);
        if (!sp.getBoolean("qh_on", false)) return false;
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int s = sp.getInt("qh_s", 23);
        int e = sp.getInt("qh_e", 7);
        return s < e ? (h >= s && h < e) : (h >= s || h < e);
    }

    static void checkUpdate(Context c, SharedPreferences sp) {
        try {
            if (!sp.getBoolean("auto_upd", true)) return;
            String repo = c.getString(R.string.gh_repo);
            HttpURLConnection h = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/releases?per_page=8").openConnection();
            h.setRequestProperty("Accept", "application/vnd.github+json");
            h.setRequestProperty("User-Agent", "KhaledAhmedApp");
            h.setConnectTimeout(10000);
            h.setReadTimeout(10000);
            if (h.getResponseCode() != 200) return;
            BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
            StringBuilder s = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) s.append(l);
            r.close();
            JSONArray list = new JSONArray(s.toString());
            long cur = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).getLongVersionCode() - 10;
            for (int k = 0; k < list.length(); k++) {
                JSONObject j = list.getJSONObject(k);
                if (j.optBoolean("draft", false)) continue;
                boolean apk = false;
                JSONArray as = j.optJSONArray("assets");
                if (as != null) {
                    for (int i = 0; i < as.length(); i++) {
                        if (as.getJSONObject(i).optString("name", "").toLowerCase().endsWith(".apk")) apk = true;
                    }
                }
                if (!apk) continue;
                int n = Integer.parseInt(j.optString("tag_name", "").replaceAll("\\D", ""));
                if (n > cur && sp.getInt("seen_u", 0) < n) {
                    show(c, 1004, "تحديث جديد للتطبيق", "الإصدار " + n + " متاح. اضغط لتحديث التطبيق الآن.", "#/update", "", "", "");
                    sp.edit().putInt("seen_u", n).apply();
                }
                break;
            }
        } catch (Exception e) {
        }
    }

    static String str(JSONObject f, String k) {
        try {
            return f.has(k) ? f.getJSONObject(k).optString("stringValue", "") : "";
        } catch (Exception e) {
            return "";
        }
    }

    static long num(JSONObject f, String k) {
        try {
            if (!f.has(k)) return 0;
            JSONObject o = f.getJSONObject(k);
            if (o.has("integerValue")) return Long.parseLong(o.getString("integerValue"));
            return (long) o.optDouble("doubleValue", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    static JSONObject latest(String col, String field) {
        try {
            String q = "{\"structuredQuery\":{\"from\":[{\"collectionId\":\"" + col + "\"}],\"orderBy\":[{\"field\":{\"fieldPath\":\"" + field + "\"},\"direction\":\"DESCENDING\"}],\"limit\":1}}";
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + ":runQuery?key=" + KEY).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            OutputStream o = c.getOutputStream();
            o.write(q.getBytes("UTF-8"));
            o.close();
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder s = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) s.append(l);
            r.close();
            JSONArray a = new JSONArray(s.toString());
            for (int i = 0; i < a.length(); i++) {
                JSONObject d = a.getJSONObject(i);
                if (d.has("document")) return d.getJSONObject("document");
            }
        } catch (Exception e) {
        }
        return null;
    }

    static Bitmap fetchBitmap(String u) {
        try {
            if (u == null || !u.startsWith("https://")) return null;
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            InputStream in = c.getInputStream();
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CH) == null) {
                NotificationChannel ch = new NotificationChannel(CH, "إشعارات الموقع", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("أخبار وتنبيهات التطبيق");
                ch.enableVibration(true);
                ch.enableLights(true);
                ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
                ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa);
                nm.createNotificationChannel(ch);
            }
        }
    }

    static PendingIntent target(Context c, int id, String link) {
        Intent in;
        if (link != null && link.startsWith("https://")) {
            in = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        } else {
            String h = (link == null || link.isEmpty()) ? "#/" : link;
            in = new Intent(Intent.ACTION_VIEW, Uri.parse("khaledapp://go?h=" + Uri.encode(h)));
            in.setPackage(c.getPackageName());
        }
        return PendingIntent.getActivity(c, id, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void show(Context c, int id, String title, String body, String link, String img, String btn, String btnUrl) {
        try {
            if (quiet(c) || !NotificationManagerCompat.from(c).areNotificationsEnabled()) return;
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat_ka)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(target(c, id, link))
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setColor(AccentUtil.c1(c));
            Bitmap bmp = fetchBitmap(img);
            if (bmp != null) {
                b.setLargeIcon(bmp);
                b.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bmp).bigLargeIcon((Bitmap) null).setSummaryText(body));
            } else {
                b.setStyle(new NotificationCompat.BigTextStyle().bigText(body));
            }
            if (btn != null && !btn.isEmpty() && btnUrl != null && (btnUrl.startsWith("https://") || btnUrl.startsWith("#/"))) {
                b.addAction(0, btn, target(c, id + 500, btnUrl));
            }
            NotificationManagerCompat.from(c).notify((int) (System.currentTimeMillis() % 2000000000L), b.build());
        } catch (SecurityException e) {
        }
    }
}
