package com.khaledahmed.app;

import android.content.Context;

public class AccentUtil {
    static int c1(Context c) {
        return c.getSharedPreferences("ka", 0).getInt("acc", 0xFF3B9CFF);
    }

    static int c2(Context c) {
        int a = c1(c);
        int r = (a >> 16) & 255;
        int g = (a >> 8) & 255;
        int b = a & 255;
        r = r + (255 - r) * 45 / 100;
        g = g + (255 - g) * 45 / 100;
        b = b + (255 - b) * 45 / 100;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static int alpha(int color, int a) {
        return (a << 24) | (color & 0x00FFFFFF);
    }
}
