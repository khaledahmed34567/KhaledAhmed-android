package com.khaledahmed.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class KaCveWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(final Context c, final AppWidgetManager m, final int[] ids) {
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    render(c, m, ids, true);
                } catch (Exception e) {
                } finally {
                    pr.finish();
                }
            }
        }).start();
    }

    @Override
    public void onAppWidgetOptionsChanged(final Context c, final AppWidgetManager m, final int id, Bundle o) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    render(c, m, new int[]{id}, false);
                } catch (Exception e) {
                }
            }
        }).start();
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, KaCveWidget.class));
        if (ids.length > 0) {
            Intent i = new Intent(c, KaCveWidget.class);
            i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            c.sendBroadcast(i);
        }
    }

    static String http(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/json");
        if (c.getResponseCode() != 200) throw new Exception("http " + c.getResponseCode());
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder s = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) s.append(l);
        r.close();
        return s.toString();
    }

    static int rank(String s) {
        if ("CRITICAL".equals(s)) return 4;
        if ("HIGH".equals(s)) return 3;
        if ("MEDIUM".equals(s)) return 2;
        if ("LOW".equals(s)) return 1;
        return 0;
    }

    static int color(String s) {
        if ("CRITICAL".equals(s)) return 0xFFFF453A;
        if ("HIGH".equals(s)) return 0xFFFF9F0A;
        if ("MEDIUM".equals(s)) return 0xFFF1C21B;
        if ("LOW".equals(s)) return 0xFF30D158;
        return 0xFF8E8E93;
    }

    static JSONObject load(Context c, boolean fetch) {
        SharedPreferences sp = c.getSharedPreferences("ka", 0);
        JSONObject d = new JSONObject();
        try {
            String j = sp.getString("cve_json", "");
            if (!j.isEmpty()) d = new JSONObject(j);
        } catch (Exception e) {
        }
        if (!fetch) return d;
        long now = System.currentTimeMillis();
        if (now - sp.getLong("cve_t", 0) < 25 * 60 * 1000L && d.has("items")) return d;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            String url = "https://services.nvd.nist.gov/rest/json/cves/2.0?pubStartDate=" + URLEncoder.encode(f.format(new Date(now - 2 * 86400000L)), "UTF-8") + "&pubEndDate=" + URLEncoder.encode(f.format(new Date(now)), "UTF-8") + "&resultsPerPage=100";
            JSONObject j = new JSONObject(http(url));
            JSONArray vs = j.optJSONArray("vulnerabilities");
            ArrayList<JSONObject> list = new ArrayList<JSONObject>();
            int crit = 0;
            int high = 0;
            if (vs != null) {
                for (int i = 0; i < vs.length(); i++) {
                    JSONObject cve = vs.getJSONObject(i).optJSONObject("cve");
                    if (cve == null) continue;
                    JSONObject m = cve.optJSONObject("metrics");
                    JSONObject mm = null;
                    if (m != null) {
                        String[] ks = {"cvssMetricV31", "cvssMetricV40", "cvssMetricV30", "cvssMetricV2"};
                        for (String k : ks) {
                            JSONArray a = m.optJSONArray(k);
                            if (a != null && a.length() > 0) {
                                mm = a.getJSONObject(0);
                                break;
                            }
                        }
                    }
                    JSONObject cd = mm != null ? mm.optJSONObject("cvssData") : null;
                    String sev = "";
                    double score = 0;
                    if (cd != null) {
                        sev = cd.optString("baseSeverity", "");
                        score = cd.optDouble("baseScore", 0);
                    }
                    if (sev.isEmpty() && mm != null) sev = mm.optString("baseSeverity", "");
                    sev = sev.toUpperCase(Locale.US);
                    String desc = "";
                    JSONArray ds = cve.optJSONArray("descriptions");
                    if (ds != null) {
                        for (int k = 0; k < ds.length(); k++) {
                            JSONObject o = ds.getJSONObject(k);
                            if ("en".equals(o.optString("lang"))) {
                                desc = o.optString("value", "");
                                break;
                            }
                        }
                    }
                    JSONObject it = new JSONObject();
                    it.put("id", cve.optString("id", ""));
                    it.put("score", score);
                    it.put("sev", sev);
                    it.put("desc", desc.length() > 160 ? desc.substring(0, 160) : desc);
                    it.put("pub", cve.optString("published", ""));
                    list.add(it);
                    if ("CRITICAL".equals(sev)) crit++;
                    if ("HIGH".equals(sev)) high++;
                }
            }
            Collections.sort(list, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject a, JSONObject b) {
                    int r = rank(b.optString("sev")) - rank(a.optString("sev"));
                    if (r != 0) return r;
                    return b.optString("pub").compareTo(a.optString("pub"));
                }
            });
            JSONArray items = new JSONArray();
            for (int i = 0; i < list.size() && i < 8; i++) items.put(list.get(i));
            d = new JSONObject();
            d.put("total", list.size());
            d.put("crit", crit);
            d.put("high", high);
            d.put("items", items);
            sp.edit().putString("cve_json", d.toString()).putLong("cve_t", now).apply();
        } catch (Exception e) {
        }
        return d;
    }

    static void render(Context c, AppWidgetManager m, int[] ids, boolean fetch) {
        JSONObject d = load(c, fetch);
        float dens = c.getResources().getDisplayMetrics().density;
        for (int id : ids) {
            Bundle o = m.getAppWidgetOptions(id);
            int wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
            int hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120);
            if (wdp < 100) wdp = 250;
            if (hdp < 70) hdp = 120;
            int w = Math.min((int) (wdp * dens), 1100);
            int h = Math.min((int) (hdp * dens), 700);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_cve);
            rv.setImageViewBitmap(R.id.cve_img, draw(c, d, w, h, dens));
            Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("khaledapp://go?h=" + Uri.encode("#/cves")));
            in.setPackage(c.getPackageName());
            rv.setOnClickPendingIntent(R.id.cve_img, PendingIntent.getActivity(c, 310, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            m.updateAppWidget(id, rv);
        }
    }

    static float pill(Canvas cv, String t, float x, float y, int col, Typeface tf, float size, float s) {
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setTypeface(tf);
        q.setTextSize(size);
        float tw = q.measureText(t);
        float pw = tw + 14 * s;
        float ph = size + 9 * s;
        RectF r = new RectF(x, y - ph + 4 * s, x + pw, y + 4 * s);
        q.setColor((col & 0x00FFFFFF) | 0x33000000);
        cv.drawRoundRect(r, ph / 2, ph / 2, q);
        q.setColor(col);
        q.setTextAlign(Paint.Align.CENTER);
        cv.drawText(t, (r.left + r.right) / 2f, y, q);
        return pw;
    }

    static Bitmap draw(Context c, JSONObject d, int w, int h, float s) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = 24 * s;
        RectF r = new RectF(2 * s, 2 * s, w - 2 * s, h - 2 * s);
        p.setColor(0xFF0B0B0D);
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(new RadialGradient(w * 0.12f, h * 0.05f, w * 0.8f, 0x55FF453A, 0x00FF453A, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s);
        p.setColor(0x33FFFFFF);
        cv.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        Typeface head = KaWidget.tf(c, "head.otf");
        Typeface time = KaWidget.tf(c, "time.otf");
        float pad = 14 * s;
        float cx = w - pad - 9 * s;
        float cy = pad + 11 * s;
        Path sp = new Path();
        sp.moveTo(cx, cy - 10 * s);
        sp.lineTo(cx + 9 * s, cy - 6 * s);
        sp.lineTo(cx + 9 * s, cy + 1 * s);
        sp.quadTo(cx + 9 * s, cy + 9 * s, cx, cy + 12 * s);
        sp.quadTo(cx - 9 * s, cy + 9 * s, cx - 9 * s, cy + 1 * s);
        sp.lineTo(cx - 9 * s, cy - 6 * s);
        sp.close();
        p.setColor(0xFFFF453A);
        cv.drawPath(sp, p);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(head);
        tp.setTextSize(14 * s);
        tp.setColor(0xFFFFFFFF);
        tp.setTextAlign(Paint.Align.RIGHT);
        cv.drawText("رادار الثغرات", w - pad - 24 * s, pad + 16 * s, tp);

        JSONArray items = d.optJSONArray("items");
        float px = pad;
        px += pill(cv, "حرجة " + d.optInt("crit", 0), px, pad + 16 * s, 0xFFFF453A, head, 10.5f * s, s) + 6 * s;
        pill(cv, "عالية " + d.optInt("high", 0), px, pad + 16 * s, 0xFFFF9F0A, head, 10.5f * s, s);

        float y0 = pad + 34 * s;
        float rowH = 26 * s;
        int fit = (int) ((h - y0 - pad + 4 * s) / rowH);
        if (items == null || items.length() == 0) {
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTextSize(13 * s);
            tp.setColor(0xFFA8A8A8);
            cv.drawText(d.has("items") ? "لا توجد ثغرات حديثة" : "جارِ التحميل...", w / 2f, h * 0.6f, tp);
            return b;
        }
        int n = Math.min(fit, items.length());
        TextPaint dp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        dp.setTypeface(Typeface.SANS_SERIF);
        dp.setTextSize(10 * s);
        dp.setColor(0xFFB8B8B8);
        TextPaint ip = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        ip.setTypeface(time);
        ip.setTextSize(11 * s);
        ip.setColor(0xFFFFFFFF);
        ip.setTextAlign(Paint.Align.RIGHT);
        TextPaint sc = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        sc.setTypeface(time);
        sc.setTextSize(11 * s);
        sc.setTextAlign(Paint.Align.RIGHT);
        for (int i = 0; i < n; i++) {
            try {
                JSONObject it = items.getJSONObject(i);
                float y = y0 + i * rowH;
                RectF rr = new RectF(pad, y, w - pad, y + rowH - 4 * s);
                p.setColor(0x14FFFFFF);
                cv.drawRoundRect(rr, 10 * s, 10 * s, p);
                int col = color(it.optString("sev"));
                p.setColor(col);
                cv.drawRoundRect(new RectF(w - pad - 4 * s, y + 4 * s, w - pad - 1 * s, y + rowH - 8 * s), 2 * s, 2 * s, p);
                float base = y + (rowH - 4 * s) * 0.66f;
                float xr = w - pad - 12 * s;
                String id = it.optString("id", "");
                cv.drawText(id, xr, base, ip);
                float idw = ip.measureText(id);
                String score = it.optDouble("score", 0) > 0 ? String.valueOf(it.optDouble("score")) : "-";
                sc.setColor(col);
                float xs = xr - idw - 8 * s;
                cv.drawText(score, xs, base, sc);
                float scw = sc.measureText(score);
                float avail = xs - scw - 8 * s - (pad + 10 * s);
                if (avail > 20 * s) {
                    CharSequence t = TextUtils.ellipsize(it.optString("desc", ""), dp, avail, TextUtils.TruncateAt.END);
                    dp.setTextAlign(Paint.Align.LEFT);
                    cv.drawText(t, 0, t.length(), pad + 10 * s, base, dp);
                }
            } catch (Exception e) {
            }
        }
        return b;
    }
}
