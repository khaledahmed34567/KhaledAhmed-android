package com.khaledahmed.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextPaint;
import android.widget.RemoteViews;

public class KaQuickWidget extends AppWidgetProvider {
    static final String[] KEYS = {"library", "wallpapers", "search", "saved"};
    static final String[] LABELS = {"المكتبة", "الخلفيات", "بحث", "المحفوظات"};
    static final int[] COLORS = {0xFFFF9F0A, 0xFF5E5CE6, 0xFF0A84FF, 0xFFFF375F};

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) draw(c, m, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        draw(c, m, id);
    }

    static void draw(Context c, AppWidgetManager m, int id) {
        try {
            Bundle o = m.getAppWidgetOptions(id);
            float dens = c.getResources().getDisplayMetrics().density;
            int wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
            int hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 70);
            if (wdp < 60) wdp = 250;
            if (hdp < 40) hdp = 70;
            int cw = Math.min((int) (wdp * dens / 4f), 300);
            int ch = Math.min((int) (hdp * dens), 300);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_quick);
            int[] views = {R.id.q1, R.id.q2, R.id.q3, R.id.q4};
            for (int i = 0; i < 4; i++) {
                rv.setImageViewBitmap(views[i], tile(c, i, cw, ch, dens));
                Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("khaledapp://open/" + KEYS[i]));
                in.setPackage(c.getPackageName());
                PendingIntent pi = PendingIntent.getActivity(c, 100 + i, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                rv.setOnClickPendingIntent(views[i], pi);
            }
            m.updateAppWidget(id, rv);
        } catch (Exception e) {
        }
    }

    static Bitmap tile(Context c, int i, int w, int h, float s) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float m = 3 * s;
        float rad = 18 * s;
        RectF r = new RectF(m, m, w - m, h - m);
        p.setColor(0xFF111111);
        cv.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s);
        p.setColor(0x33FFFFFF);
        cv.drawRoundRect(r, rad, rad, p);
        float cx = w / 2f;
        float cy = h * 0.40f;
        float cr = Math.min(w, h) * 0.22f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(i == 1 ? AccentUtil.c1(c) : COLORS[i]);
        cv.drawCircle(cx, cy, cr, p);
        icon(cv, i, cx, cy, cr * 0.55f);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(KaWidget.tf(c, "head.otf"));
        tp.setColor(0xFFF4F4F4);
        tp.setTextSize(Math.min(11f * s, w * 0.16f));
        tp.setTextAlign(Paint.Align.CENTER);
        cv.drawText(LABELS[i], cx, h * 0.84f, tp);
        return b;
    }

    static void icon(Canvas cv, int i, float cx, float cy, float u) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(u * 0.28f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        if (i == 0) {
            cv.drawLine(cx - u, cy - u, cx - u, cy + u, p);
            cv.drawLine(cx, cy - u, cx, cy + u, p);
            cv.drawLine(cx + u, cy - u * 0.8f, cx + u * 1.2f, cy + u, p);
        } else if (i == 1) {
            cv.drawRoundRect(new RectF(cx - u, cy - u * 0.8f, cx + u, cy + u * 0.8f), u * 0.25f, u * 0.25f, p);
            Path path = new Path();
            path.moveTo(cx - u, cy + u * 0.5f);
            path.lineTo(cx - u * 0.2f, cy - u * 0.1f);
            path.lineTo(cx + u * 0.3f, cy + u * 0.35f);
            path.lineTo(cx + u * 0.6f, cy + u * 0.1f);
            path.lineTo(cx + u, cy + u * 0.5f);
            cv.drawPath(path, p);
        } else if (i == 2) {
            cv.drawCircle(cx - u * 0.15f, cy - u * 0.15f, u * 0.7f, p);
            cv.drawLine(cx + u * 0.35f, cy + u * 0.35f, cx + u, cy + u, p);
        } else {
            Path path = new Path();
            path.moveTo(cx - u * 0.6f, cy - u);
            path.lineTo(cx + u * 0.6f, cy - u);
            path.lineTo(cx + u * 0.6f, cy + u);
            path.lineTo(cx, cy + u * 0.5f);
            path.lineTo(cx - u * 0.6f, cy + u);
            path.close();
            cv.drawPath(path, p);
        }
    }
}
