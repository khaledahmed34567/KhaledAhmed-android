# تطبيق Khaled Ahmed للأندرويد

هذا المشروع يحوّل الموقع إلى تطبيق APK بنفس التصميم والخطوط وقاعدة البيانات، ويُبنى تلقائيًا على GitHub بدون برامج على جهازك.

## الخطوات (من الهاتف أو الكمبيوتر)

1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع ملف `KhaledAhmed-App.zip` كما هو في جذر المستودع (Add file ثم Upload files). لا تفكّ ضغطه.
3. أنشئ الملف `.github/workflows/build.yml` (Add file ثم Create new file، واكتب المسار كاملًا) والصق محتوى ملف `build.yml` المرفق.
4. في Firebase Console لمشروع `cyberintel-d0d4f`:
   - Project settings ثم Add app ثم Android. اسم الحزمة: `com.khaledahmed.app`
   - بصمة SHA-1: `0E:52:7F:8D:E4:D8:D6:14:6F:62:1C:6F:D8:06:8C:D5:04:58:D3:FF`
   - نزّل `google-services.json` وارفعه في جذر المستودع بنفس الاسم (مطلوب للإشعارات).
   - Authentication ثم Sign-in method: فعّل Google وانسخ Web client ID.
5. في GitHub: Settings ثم Secrets and variables ثم Actions ثم تبويب Variables، وأضف:
   - `WEB_CLIENT_ID` = الـ Web client ID من الخطوة السابقة.
   - `SITE_URL` = رابط موقعك على GitHub Pages ينتهي بـ / (يُستخدم في روابط المشاركة داخل التطبيق).
6. تبويب Actions ثم Build APK ثم Run workflow.
7. بعد دقائق: تبويب Releases ثم حمّل `KhaledAhmed.apk` وثبّته (اسمح بالتثبيت من مصادر غير معروفة).

## ما في التطبيق
- نفس الموقع: التصميم والخطوط واللوجو وقاعدة البيانات والحسابات.
- تسجيل بالبريد مع تفعيل الحساب، وتغيير كلمة المرور بالإيميل، وتسجيل Google الأصلي.
- القفل بالبصمة من الملف الشخصي.
- إشعارات عائمة على الهاتف، وودجت للشاشة الرئيسية بخطوط الموقع.
- حفظ الخلفيات في معرض الصور (Pictures/KhaledAhmed).
- المساعد الذكي يقرأ محتوى الشاشة، ويظهر فقط بعد إضافة مفتاح Gemini.

## الإشعارات
- من لوحة الأدمن (الإعدادات) أرسل إشعارًا: يصل لمن التطبيق يعمل عنده.
- للوصول إليهم والتطبيق مغلق: من Firebase Console ثم Messaging أرسل إشعارًا مستهدفًا التطبيق، أو انشر دالة السحابة في مجلد functions (تحتاج Blaze).

## أخطاء شائعة
- تسجيل Google يعطي الرمز 10: SHA-1 أو اسم الحزمة غير مضاف في Firebase، أو WEB_CLIENT_ID غير مضبوط.
- لا تصل إشعارات: تأكد من رفع google-services.json ثم أعد البناء.

التطبيق مبني على Android 10 أو أحدث.
